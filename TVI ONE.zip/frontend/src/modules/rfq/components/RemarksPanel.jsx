import { useState } from "react";
import api from "../../../services/api";
import { ENDPOINTS } from "../../../services/endpoints";
import { Panel, Select } from "../../../components/ui";
import { formatDateTime, humanize } from "../utils/rfqFormat";

// Every stage has its own thread; anyone who can see the RFQ can add as many remarks as needed.
export default function RemarksPanel({ rfqId, stages, currentStage, remarks, onAdded }) {
  const [stage, setStage] = useState(currentStage);
  const [text, setText] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const countFor = (stageName) => remarks.filter((remark) => remark.stage === stageName).length;
  const stageRemarks = remarks.filter((remark) => remark.stage === stage);

  const submit = async () => {
    setSaving(true);
    setError("");
    try {
      await api.post(ENDPOINTS.RFQ.REMARKS(rfqId), { stage, text });
      setText("");
      await onAdded();
    } catch (e) {
      setError(e.response?.data?.error || "Could not save the remark");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Panel title="Stage remarks">
      <label className="text-[10px] font-bold uppercase text-slate-500">
        Stage
        <Select value={stage} onChange={(event) => setStage(event.target.value)}>
          {stages.map((name) => <option key={name} value={name}>{`${humanize(name)} (${countFor(name)})`}</option>)}
        </Select>
      </label>
      <ul className="my-2 space-y-1.5">
        {stageRemarks.length === 0 && <li className="text-xs text-slate-400">No remarks for this stage yet.</li>}
        {stageRemarks.map((remark) => (
          <li key={remark._id} className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs text-slate-700">
            <p className="whitespace-pre-wrap">{remark.text}</p>
            <p className="mt-1 text-[10px] text-slate-400">{remark.user_name} · {humanize(remark.user_role)} · {formatDateTime(remark.createdAt)}</p>
          </li>
        ))}
      </ul>
      <textarea
        value={text}
        onChange={(event) => setText(event.target.value)}
        rows={2}
        placeholder="Add a remark for this stage…"
        className="w-full rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-xs focus:border-indigo-500 focus:outline-none"
      />
      {error && <p className="text-xs text-rose-600">{error}</p>}
      <button type="button" onClick={submit} disabled={saving || !text.trim()} className="mt-1 rounded-lg bg-slate-800 px-3 py-1.5 text-xs font-bold text-white disabled:opacity-40">
        {saving ? "Saving…" : "Add remark"}
      </button>
    </Panel>
  );
}
