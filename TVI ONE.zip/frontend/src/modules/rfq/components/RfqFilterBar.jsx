import ExcelFilterDropdown from "../../../components/ExcelFilterDropdown";
import { GhostButton } from "../../../components/ui";
import { FILTER_COLUMNS } from "../hooks/useRfqFilters";

export default function RfqFilterBar({ options, filters, hasFilters, onChange, onReset }) {
  return (
    <div className="flex flex-wrap items-center gap-2">
      {FILTER_COLUMNS.map(({ key, title }) => (
        <ExcelFilterDropdown key={key} title={title} options={options[key] || []} selectedValues={filters[key]} onChange={(values) => onChange(key, values)} />
      ))}
      {hasFilters && <GhostButton onClick={onReset}>Clear filters</GhostButton>}
    </div>
  );
}
