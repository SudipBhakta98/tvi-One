import { Table } from "../../../components/ui";
import { formatDate, humanize } from "../utils/rfqFormat";

const LATE_STATUSES = ["DELAY_PENDING", "DELAY_DONE"];
const REMARK_PREVIEW_WIDTH = "max-w-[16rem]";
const COLUMNS = ["RFQ No", "Customer", "Project", "Project Owner", "Current Stage", "Due Date", "Latest Remark", "Status"];

export default function RfqRegisterTable({ rows, onSelect }) {
  return (
    <Table columns={COLUMNS}>
      {rows.map((rfq) => {
        const isLate = LATE_STATUSES.includes(rfq.current_stage_status);
        return (
          <tr key={rfq._id} onClick={() => onSelect(rfq._id)} className="cursor-pointer hover:bg-slate-50">
            <td className="px-3 py-2 text-xs font-semibold text-slate-800">{rfq.rfq_number}</td>
            <td className="px-3 py-2 text-xs text-slate-700">{rfq.customer}</td>
            <td className="px-3 py-2 text-xs text-slate-700">{rfq.project_name}</td>
            <td className="px-3 py-2 text-xs text-slate-700">{rfq.project_owner_name}</td>
            <td className="px-3 py-2 text-xs text-slate-700">{humanize(rfq.current_stage)}</td>
            <td className={`px-3 py-2 text-xs ${isLate ? "font-bold text-rose-600" : "text-slate-700"}`}>
              {formatDate(rfq.current_due_date)}{isLate && " (overdue)"}
            </td>
            <td className={`px-3 py-2 text-xs text-slate-600 truncate ${REMARK_PREVIEW_WIDTH}`} title={rfq.latest_remark?.text}>
              {rfq.latest_remark ? `${rfq.latest_remark.text} — ${rfq.latest_remark.user_name}` : "—"}
            </td>
            <td className="px-3 py-2 text-xs text-slate-700">{humanize(rfq.rfq_status)}</td>
          </tr>
        );
      })}
    </Table>
  );
}
