import { useCallback, useEffect, useState } from "react";
import api from "../../../services/api";
import { ENDPOINTS } from "../../../services/endpoints";
import { Panel, Table, EmptyState } from "../../../components/ui";
import RemarksPanel from "./RemarksPanel";
import { flattenScalars, formatValue, humanize } from "../utils/rfqFormat";

const HIDDEN_KEYS = ["_id", "__v", "id"];
const labelFor = (path) => humanize(path.replaceAll(".", " › "));

// Every list on the RFQ, as its own table. Anything that is not a list is rendered by the field grid.
const tableSections = (rfq) => ({
  main_parts: rfq.main_parts,
  sub_parts: rfq.main_parts?.flatMap((part) => (part.sub_parts || []).map((sub) => ({ main_part_no: part.main_part_no, ...sub }))),
  stage_schedule: rfq.stage_schedule,
  stage_history: rfq.stage_history,
  purchase_items: rfq.purchase_items,
  delivery_schedule: rfq.purchase_order?.delivery_schedule,
  attachments: Object.entries(rfq.stage_attachments || {}).flatMap(([stage, files]) => files.map((file) => ({ stage, ...file }))),
});

function FieldGrid({ record }) {
  const fields = Object.entries(flattenScalars(record)).filter(([path]) => !HIDDEN_KEYS.includes(path.split(".").pop()) && !path.startsWith("permissions"));
  return (
    <dl className="grid grid-cols-1 gap-x-4 gap-y-2 sm:grid-cols-2 lg:grid-cols-3">
      {fields.map(([path, value]) => (
        <div key={path}><dt className="text-[10px] font-bold uppercase text-slate-500">{labelFor(path)}</dt><dd className="break-words text-xs text-slate-800">{formatValue(value)}</dd></div>
      ))}
    </dl>
  );
}

function RowsTable({ rows }) {
  const flatRows = rows.map((row) => flattenScalars(row));
  const columns = [...new Set(flatRows.flatMap(Object.keys))].filter((key) => !HIDDEN_KEYS.includes(key.split(".").pop()));
  return (
    <div className="overflow-x-auto">
      <Table columns={columns.map(labelFor)}>
        {flatRows.map((row, index) => <tr key={index}>{columns.map((key) => <td key={key} className="px-3 py-2 text-xs text-slate-700">{formatValue(row[key])}</td>)}</tr>)}
      </Table>
    </div>
  );
}

export default function RfqDetailsView({ rfqId, onClose }) {
  const [summary, setSummary] = useState(null);
  const load = useCallback(async () => {
    const [workflow, detail] = await Promise.all([api.get(ENDPOINTS.RFQ.WORKFLOW(rfqId)), api.get(`${ENDPOINTS.RFQ.BASE}/${rfqId}`)]);
    setSummary({ ...workflow.data, detail: detail.data });
  }, [rfqId]);
  useEffect(() => { load(); }, [load]);

  if (!summary) return <div className="rounded-xl bg-white p-8 text-center text-xs text-slate-500">Loading RFQ…</div>;
  const { detail, rfq, stage_schedule: schedule } = summary;

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-bold text-slate-800">{detail.rfq_number} — {detail.project_name}</h2>
        <button type="button" onClick={onClose} className="rounded-lg border border-slate-300 px-3 py-1 text-xs font-bold text-slate-700">Close</button>
      </div>
      <Panel title="All details"><FieldGrid record={detail} /></Panel>
      <RemarksPanel rfqId={rfqId} stages={schedule.map((item) => item.stage)} currentStage={rfq.current_stage} remarks={rfq.stage_remarks || []} onAdded={load} />
      {Object.entries(tableSections(detail)).map(([name, rows]) => (
        <Panel key={name} title={humanize(name).toUpperCase()}>{rows?.length ? <RowsTable rows={rows} /> : <EmptyState message="Nothing recorded." />}</Panel>
      ))}
    </div>
  );
}
