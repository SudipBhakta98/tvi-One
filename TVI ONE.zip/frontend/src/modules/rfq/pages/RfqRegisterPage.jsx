import { useCallback, useEffect, useState } from "react";
import api from "../../../services/api";
import { ENDPOINTS } from "../../../services/endpoints";
import { PageHeader, Panel, EmptyState } from "../../../components/ui";
import useRfqFilters from "../hooks/useRfqFilters";
import RfqFilterBar from "../components/RfqFilterBar";
import RfqRegisterTable from "../components/RfqRegisterTable";
import RfqDetailsView from "../components/RfqDetailsView";

// Reference composition: filters + register + details. If your existing register page has its own create button / modal,
// keep it and lift in just useRfqFilters, RfqFilterBar, RfqRegisterTable and RfqDetailsView.
export default function RfqRegisterPage() {
  const { options, filters, params, hasFilters, setColumn, reset } = useRfqFilters();
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selectedId, setSelectedId] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    try { setRows((await api.get(ENDPOINTS.RFQ.BASE, { params })).data); } finally { setLoading(false); }
  }, [params]);
  useEffect(() => { load(); }, [load]);

  const closeDetails = () => { setSelectedId(null); load(); }; // reload so a new remark shows in the register

  return (
    <div className="space-y-3">
      <PageHeader eyebrow="NPD" title="RFQ Register" subtitle="Current stage, due date and latest remark for every RFQ you can access." />
      <Panel title="Filters"><RfqFilterBar options={options} filters={filters} hasFilters={hasFilters} onChange={setColumn} onReset={reset} /></Panel>
      <Panel title={`RFQs (${rows.length})`}>
        {loading ? <div className="p-6 text-center text-xs text-slate-500">Loading…</div> : rows.length ? <RfqRegisterTable rows={rows} onSelect={setSelectedId} /> : <EmptyState />}
      </Panel>
      {selectedId && (
        <div className="fixed inset-0 z-40 overflow-y-auto bg-slate-900/40 p-4">
          <div className="mx-auto max-w-5xl rounded-xl bg-slate-100 p-4"><RfqDetailsView rfqId={selectedId} onClose={closeDetails} /></div>
        </div>
      )}
    </div>
  );
}
