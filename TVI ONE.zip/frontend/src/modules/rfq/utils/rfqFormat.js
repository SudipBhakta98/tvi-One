const ISO_DATE_TIME = /^\d{4}-\d{2}-\d{2}T/;

export const humanize = (value) => String(value ?? "").replaceAll("_", " ");
export const formatDate = (value) => (value ? new Date(value).toLocaleDateString("en-IN") : "—");
export const formatDateTime = (value) => (value ? new Date(value).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" }) : "—");
export const formatValue = (value) => {
  if (value === null || value === undefined || value === "") return "—";
  if (typeof value === "boolean") return value ? "Yes" : "No";
  if (typeof value === "string" && ISO_DATE_TIME.test(value)) return formatDateTime(value);
  return String(value);
};

// Nested objects become "parent.child" keys; arrays are skipped (they are shown as their own tables).
export const flattenScalars = (value, prefix = "", out = {}) => {
  if (value === null || value === undefined || Array.isArray(value)) return out;
  if (typeof value === "object") Object.entries(value).forEach(([key, child]) => flattenScalars(child, prefix ? `${prefix}.${key}` : key, out));
  else out[prefix] = value;
  return out;
};
