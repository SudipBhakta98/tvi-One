import { Outlet } from "react-router-dom";
import { PayablesProvider } from "./contexts/PayableContext.jsx";
import { NotificationProvider } from "./contexts/NotificationContext.jsx";


export default function FinanceLayout() {
  return (
    <PayablesProvider>
      <NotificationProvider>
      
        <Outlet />
  
      </NotificationProvider>
    </PayablesProvider>
  );
}
  