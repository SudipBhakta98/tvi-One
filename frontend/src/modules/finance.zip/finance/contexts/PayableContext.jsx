import React, { createContext, useContext, useState } from "react";

const PayablesContext = createContext(null);

export const PayablesProvider = ({ children }) => {
  // ============================================================
  // ANALYTICS DATA
  // ============================================================

  const [analyticsData, setAnalyticsData] = useState({
    data: [],
    availablePeriods: [],
    selectedPeriods: [],
  });

  // ============================================================
  // SEARCH RESULTS
  // ============================================================

  const [searchResults, setSearchResults] = useState({
    searchPayables: [],
    pagination: {
      currentPage: 1,
      limit: 10,
      totalPages: 0,
      totalItems: 0,
    },
  });

  // ============================================================
  // SEARCH STATE
  // ============================================================

  const [searchState, setSearchState] = useState({
    search: "",
    page: 1,
    limit: 10,
    loading: false,
    error: null,
  });

  // ============================================================
  // INVOICE DETAILS
  // ============================================================

  const [detailsData, setDetailsData] = useState({
    payments: [],
    debits: [],
    totalPaidAmount: 0,
    totalPendingPaymentAmount: 0,
    totalDebitAmount: 0,
  });

  // ============================================================
  // STORE ANALYTICS
  // ============================================================

  const storeAnalytics = (responseData) => {
    setAnalyticsData({
      data: responseData?.data || [],
      availablePeriods: responseData?.availablePeriods || [],
      selectedPeriods: responseData?.selectedPeriods || [],
    });
  };

  // ============================================================
  // STORE SEARCH RESULTS
  // ============================================================

  const storeSearchResults = (responseData) => {
    setSearchResults({
      searchPayables: responseData?.searchPayables || [],
      pagination: responseData?.pagination || {
        currentPage: 1,
        limit: 10,
        totalPages: 0,
        totalItems: 0,
      },
    });
  };

  // ============================================================
  // SEARCH STATE UPDATER
  // ============================================================

  const updateSearchState = (updates) => {
    setSearchState((prev) => ({ ...prev, ...updates }));
  };

  // ============================================================
  // REMOVE INVOICE FROM CONTEXT IMMEDIATELY
  // ============================================================

  const removeInvoice = (targetId) => {
    if (!targetId) return;

    // Filter out from search results
    setSearchResults((prev) => {
      const updatedList = prev.searchPayables.filter(
        (item) => (item._id || item.id) !== targetId
      );
      const totalItems = Math.max(0, prev.pagination.totalItems - 1);
      return {
        ...prev,
        searchPayables: updatedList,
        pagination: {
          ...prev.pagination,
          totalItems,
        },
      };
    });

    // Filter out from analytics data
    setAnalyticsData((prev) => ({
      ...prev,
      data: prev.data.filter((item) => (item._id || item.id) !== targetId),
    }));

    // Reset details data
    setDetailsData({
      payments: [],
      debits: [],
      totalPaidAmount: 0,
      totalPendingPaymentAmount: 0,
      totalDebitAmount: 0,
    });
  };

  // ============================================================
  // CLEAR SEARCH
  // ============================================================

  const clearSearch = () => {
    setSearchState({
      search: "",
      page: 1,
      limit: 10,
      loading: false,
      error: null,
    });

    setSearchResults({
      searchPayables: [],
      pagination: {
        currentPage: 1,
        limit: 10,
        totalPages: 0,
        totalItems: 0,
      },
    });
  };

  // ============================================================
  // STORE INVOICE DETAILS
  // ============================================================

  const storeDetails = (responseData) => {
    const payments = responseData?.data?.payments || [];
    const debits = responseData?.data?.debits || [];

    const totalPaidAmount = payments
      .filter(
        (payment) =>
          String(payment.status || "").toLowerCase() === "approved"
      )
      .reduce((sum, payment) => sum + Number(payment.paidAmount || 0), 0);

    const totalPendingPaymentAmount = payments
      .filter(
        (payment) =>
          String(payment.status || "").toLowerCase() === "pending"
      )
      .reduce((sum, payment) => sum + Number(payment.paidAmount || 0), 0);

    const totalDebitAmount = debits.reduce(
      (sum, debit) =>
        sum +
        Number(
          debit.debitAmount ?? debit.amount ?? debit.noteAmount ?? 0
        ),
      0
    );

    setDetailsData({
      payments,
      debits,
      totalPaidAmount,
      totalPendingPaymentAmount,
      totalDebitAmount,
    });
  };

  // ============================================================
  // CONTEXT PROVIDER
  // ============================================================

  return (
    <PayablesContext.Provider
      value={{
        analyticsData,
        searchResults,
        detailsData,
        searchState,
        updateSearchState,
        storeAnalytics,
        storeSearchResults,
        storeDetails,
        clearSearch,
        removeInvoice,
      }}
    >
      {children}
    </PayablesContext.Provider>
  );
};

export const usePayables = () => {
  const context = useContext(PayablesContext);

  if (!context) {
    throw new Error("usePayables must be used within a PayablesProvider");
  }

  return context;
};