import React, { createContext, useContext, useState, useRef } from "react";

const NotificationContext = createContext(null);

export const NotificationProvider = ({ children }) => {
  const [notification, setNotification] = useState(null); // { message, type: 'success' | 'error' | 'warning' }
  const timerRef = useRef(null);

  const showNotification = (message, type = "success") => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
    }

    setNotification({ message, type });

    timerRef.current = setTimeout(() => {
      setNotification(null);
    }, 5000);
  };

  const clearNotification = () => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
    }
    setNotification(null);
  };

  return (
    <NotificationContext.Provider value={{ showNotification, clearNotification }}>
      {children}

      {/* GLOBAL NOTIFICATION BANNER */}
      {notification && (
        <div className="fixed top-2 left-1/2 -translate-x-1/2 z-[9999] w-full max-w-md px-3 animate-fadeIn">
          <div
            className={`flex items-center justify-between p-3 rounded-xl border shadow-2xl backdrop-blur-md text-xs font-bold ${
              notification.type === "success"
                ? "border-emerald-500/40 bg-emerald-50/95 text-emerald-800"
                : notification.type === "warning"
                ? "border-amber-500/40 bg-amber-50/95 text-amber-900"
                : "border-rose-500/40 bg-rose-50/95 text-rose-800"
            }`}
          >
            <div className="flex items-center gap-2 pr-2">
              <span className="text-base">
                {notification.type === "success"
                  ? "✅"
                  : notification.type === "warning"
                  ? "⚠️"
                  : "❌"}
              </span>
              <span>{notification.message}</span>
            </div>
            <button
              onClick={clearNotification}
              className="px-2 py-1 rounded transition-colors bg-white/60 hover:bg-white text-slate-700"
            >
              ✕
            </button>
          </div>
        </div>
      )}
    </NotificationContext.Provider>
  );
};

export const useNotification = () => {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error("useNotification must be used within a NotificationProvider");
  }
  return context;
};