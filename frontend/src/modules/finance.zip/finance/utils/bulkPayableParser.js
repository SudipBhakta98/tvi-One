import * as XLSX from "xlsx";

const REQUIRED_COLUMNS = [
  "invoiceNumber",
  "grnNumber",
  "supplierName",
  "invoiceDate",
  "subTotal",
  "gstRate",
  "totalAmount",
  "tdsRate",
];

const COLUMN_ALIASES = {
  invoiceNumber: ["invoicenumber", "invoice_number", "invoice no", "invoice number"],
  grnNumber: ["grnnumber", "grn_number", "grn no", "grn number"],
  supplierName: ["suppliername", "supplier_name", "supplier", "supplier name"],
  invoiceDate: ["invoicedate", "invoice_date", "invoice date", "date"],
  subTotal: ["subtotal", "sub_total", "sub total", "sub-total"],
  gstRate: ["gstrate", "gst_rate", "gst rate", "gst %", "gst"],
  totalAmount: ["totalamount", "total_amount", "total amount", "invoice total"],
  tdsRate: ["tdsrate", "tds_rate", "tds rate", "tds %", "tds"],
};

const cleanHeader = (value) =>
  String(value ?? "")
    .trim()
    .toLowerCase()
    .replace(/[\r\n]+/g, " ")
    .replace(/\s+/g, " ");

const findCanonicalColumn = (header) => {
  const normalized = cleanHeader(header);
  return Object.entries(COLUMN_ALIASES).find(([, aliases]) =>
    aliases.some((alias) => cleanHeader(alias) === normalized),
  )?.[0];
};

const pad = (value) => String(value).padStart(2, "0");

const toIsoDate = (value) => {
  if (value === null || value === undefined || value === "") return null;

  if (value instanceof Date && !Number.isNaN(value.getTime())) {
    return `${value.getFullYear()}-${pad(value.getMonth() + 1)}-${pad(value.getDate())}`;
  }

  if (typeof value === "number" && Number.isFinite(value)) {
    const parsed = XLSX.SSF.parse_date_code(value);
    if (parsed?.y && parsed?.m && parsed?.d) {
      return `${parsed.y}-${pad(parsed.m)}-${pad(parsed.d)}`;
    }
  }

  const raw = String(value).trim();
  if (!raw) return null;

  // yyyy-mm-dd / yyyy/mm/dd / yyyy.mm.dd
  let match = raw.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})/);
  if (match) return `${match[1]}-${pad(match[2])}-${pad(match[3])}`;

  // dd-mm-yyyy / dd/mm/yyyy / dd.mm.yyyy
  match = raw.match(/^(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})$/);
  if (match) return `${match[3]}-${pad(match[2])}-${pad(match[1])}`;

  // 31 Aug 2026 / Aug 31 2026 / 31 August 2026
  const native = new Date(raw);
  if (!Number.isNaN(native.getTime())) {
    return `${native.getFullYear()}-${pad(native.getMonth() + 1)}-${pad(native.getDate())}`;
  }

  return null;
};

export const BULK_PAYABLE_COLUMNS = REQUIRED_COLUMNS;

export const BULK_PAYABLE_COLUMN_GUIDE = [
  { key: "invoiceNumber", label: "Invoice Number", required: true, example: "INV-2026-001" },
  { key: "grnNumber", label: "GRN Number", required: true, example: "GRN-1001" },
  { key: "supplierName", label: "Supplier Name", required: true, example: "ABC Industries" },
  { key: "invoiceDate", label: "Invoice Date", required: true, example: "31/08/2026" },
  { key: "subTotal", label: "Sub Total", required: true, example: "100000" },
  { key: "gstRate", label: "GST Rate", required: true, example: "18" },
  { key: "totalAmount", label: "Total Amount", required: true, example: "118000" },
  { key: "tdsRate", label: "TDS Rate", required: true, example: "1" },
];

export const parseBulkPayableFile = async (file) => {
  if (!file) throw new Error("Please select an Excel or CSV file.");

  const lowerName = file.name.toLowerCase();
  const supported = [".xlsx", ".xls", ".csv"].some((ext) => lowerName.endsWith(ext));
  if (!supported) throw new Error("Only .xlsx, .xls and .csv files are supported.");

  const buffer = await file.arrayBuffer();
  const workbook = XLSX.read(buffer, {
    type: "array",
    cellDates: true,
    raw: true,
  });

  const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
  if (!firstSheet) throw new Error("The uploaded file does not contain a worksheet.");

  const matrix = XLSX.utils.sheet_to_json(firstSheet, {
    header: 1,
    defval: "",
    raw: true,
    blankrows: false,
  });

  if (!matrix.length) throw new Error("The uploaded file is empty.");

  const sourceHeaders = matrix[0].map(cleanHeader);
  const mappedHeaders = matrix[0].map(findCanonicalColumn);
  const missing = REQUIRED_COLUMNS.filter((column) => !mappedHeaders.includes(column));

  if (missing.length) {
    throw new Error(`Missing required columns: ${missing.join(", ")}`);
  }

  const rows = matrix.slice(1).map((row, rowIndex) => {
    const output = {};
    mappedHeaders.forEach((canonical, columnIndex) => {
      if (canonical) output[canonical] = row[columnIndex];
    });

    return {
      ...output,
      invoiceNumber: String(output.invoiceNumber ?? "").trim(),
      grnNumber: String(output.grnNumber ?? "").trim(),
      supplierName: String(output.supplierName ?? "").trim(),
      invoiceDate: toIsoDate(output.invoiceDate),
      subTotal: output.subTotal === "" ? "" : Number(output.subTotal),
      gstRate: output.gstRate === "" ? 0 : Number(output.gstRate),
      totalAmount: output.totalAmount === "" ? "" : Number(output.totalAmount),
      tdsRate: output.tdsRate === "" ? 0 : Number(output.tdsRate),
      __sourceRow: rowIndex + 2,
    };
  }).filter((row) => Object.values(row).some((value) => value !== "" && value !== null && value !== undefined));

  if (!rows.length) throw new Error("The uploaded file has no data rows.");

  return {
    rows,
    sourceHeaders,
    rowCount: rows.length,
  };
};
