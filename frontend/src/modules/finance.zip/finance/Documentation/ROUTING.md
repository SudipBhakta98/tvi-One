# Finance Routing Integration

## 1. Keep AppLayout
Do not change the AppLayout shell. Only replace the Finance group inside `groups` with:

```jsx
{
  label: "Finance",
  icon: Wallet,
  path: "/finance",
  allowed: [ROLES.FINANCE_MANAGER, ROLES.FINANCE_USER],
  children: [
    {
      label: "Payables",
      to: "/finance/payables",
      children: [
        { label: "Payable Register", to: "/finance/payables" },
        { label: "Create Payable", to: "/finance/payables?create=1", create: true },
      ],
    },
    {
      label: "Advance Payments",
      to: "/finance/advances",
      children: [
        { label: "Advance Register", to: "/finance/advances" },
        { label: "Make Advance Payment", to: "/finance/advances?create=1", create: true },
      ],
    },
    {
      label: "Credits",
      to: "/finance/credits",
      children: [
        { label: "Credit Notes", to: "/finance/credits" },
        { label: "Create Credit Note", to: "/finance/credits?create=1", create: true },
      ],
    },
  ],
},
```

## 2. Important Payable fix
`PayablesPage` must NOT remove `?create=1` in the effect that opens the create page. It should use the query string as the source of truth and remove it only when Close is clicked.

## 3. Add the route
Inside the existing `/finance` route:

```jsx
<Route path="advances" element={<AdvancePaymentPage />} />
```

Import:

```jsx
import AdvancePaymentPage from "./finance/pages/AdvancePaymentPage.jsx";
```
