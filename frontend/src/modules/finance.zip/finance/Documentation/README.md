# Finance Module Documentation

This folder contains documentation for the Finance module.

- `BulkPayableUpload.md` — exact Excel/CSV columns, browser parsing flow, JSON contract, and supported date formats.

The Finance module is rendered inside the application's existing `AppLayout`. The Finance changes do not replace or modify the application's sidebar, header, navigation, or authentication layout.
