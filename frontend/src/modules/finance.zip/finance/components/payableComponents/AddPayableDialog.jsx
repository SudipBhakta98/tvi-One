import React, { useEffect, useMemo, useRef, useState } from "react";
import { FileSpreadsheet, Upload, Download, X, ArrowLeft, CheckCircle2, AlertCircle, RefreshCw, AlertTriangle } from "lucide-react";
import { payablesApi } from "../../api.js"; 
import { BULK_PAYABLE_COLUMN_GUIDE, parseBulkPayableFile } from "../../utils/bulkPayableParser.js"// Adjust if utils is in src/utils
import { useNotification } from "../../contexts/NotificationContext.jsx"

const initialFormState = {
  invoiceNumber: "",
  grnNumber: "",
  supplierName: "",
  invoiceDate: "",
  subTotal: "",
  gstRate: "18",
  totalAmount: "",
  tdsRate: "0",
};

const formatMoney = (value) => `₹${Math.round(Number(value) || 0).toLocaleString("en-IN")}`;

function DownloadTemplate() {
  const downloadTemplate = () => {
    const header = BULK_PAYABLE_COLUMN_GUIDE.map((column) => column.key).join(",");
    const example = BULK_PAYABLE_COLUMN_GUIDE.map((column) => column.example).join(",");
    const csv = `${header}\n${example}\n`;
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = "payable-bulk-upload-template.csv";
    anchor.click();
    URL.revokeObjectURL(url);
  };

  return (
    <button
      type="button"
      onClick={downloadTemplate}
      className="inline-flex items-center gap-2 rounded-lg border border-indigo-200 bg-indigo-50 px-4 py-2.5 text-sm font-bold text-indigo-700 hover:bg-indigo-100"
    >
      <Download size={17} /> Download CSV Template
    </button>
  );
}

function BulkUploadWorkspace({ onBack, onClose, onSuccess }) {
  const inputRef = useRef(null);
  const { showNotification } = useNotification();
  const [file, setFile] = useState(null);
  const [rows, setRows] = useState([]);
  const [parseError, setParseError] = useState("");
  const [uploadError, setUploadError] = useState("");
  const [result, setResult] = useState(null);
  const [parsing, setParsing] = useState(false);
  const [uploading, setUploading] = useState(false);

  const previewRows = useMemo(() => rows.slice(0, 8), [rows]);

  const handleFile = async (selectedFile) => {
    if (!selectedFile) return;
    setFile(selectedFile);
    setRows([]);
    setResult(null);
    setParseError("");
    setUploadError("");
    setParsing(true);
    try {
      const parsed = await parseBulkPayableFile(selectedFile);
      setRows(parsed.rows);
    } catch (error) {
      setParseError(error.message || "Unable to parse the file.");
    } finally {
      setParsing(false);
    }
  };

  const handleUpload = async () => {
    if (!rows.length) {
      setUploadError("Upload a valid file with at least one data row first.");
      return;
    }

    setUploading(true);
    setUploadError("");
    setResult(null);
    try {
      const response = await payablesApi.create({ invoices: rows });
      const resData = response.data;
      setResult(resData);

      const failedInvoices = resData.failedInvoices || resData.invalidItems || [];
      const failedCount = resData.summary?.failedCount ?? failedInvoices.length;
      const successCount = resData.summary?.successfullyInserted ?? 0;

      if (failedCount > 0 && successCount > 0) {
        showNotification(
          `${failedCount} invoice(s) failed validation while ${successCount} were created successfully.`,
          "warning"
        );
      } else if (failedCount > 0 && successCount === 0) {
        showNotification(
          `Bulk upload failed. All ${failedCount} invoice(s) have validation errors.`,
          "error"
        );
      } else {
        showNotification(
          `Bulk process completed successfully! ${successCount} invoice(s) created.`,
          "success"
        );
      }

      if (successCount > 0 && onSuccess) {
        onSuccess();
      }
    } catch (error) {
      const errResponse = error.response?.data;
      const failedInvoices = errResponse?.failedInvoices || errResponse?.invalidItems || [];

      if (errResponse) {
        setResult(errResponse);
      }

      const errMsg =
        errResponse?.message ||
        error.message ||
        "Bulk payable upload failed.";

      setUploadError(errMsg);
      showNotification(errMsg, "error");

      if (failedInvoices.length > 0) {
        console.error("Bulk Upload Validation Failures:", failedInvoices);
      }
    } finally {
      setUploading(false);
    }
  };

  const failedItemsList = result?.failedInvoices || result?.invalidItems || [];

  return (
    <div className="fixed top-14 left-64 right-0 bottom-0 z-50 bg-slate-50 overflow-y-auto">
      <div className="min-h-full flex flex-col">
        <header className="sticky top-0 z-10 bg-white border-b border-slate-200 shadow-sm px-6 py-4 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onBack}
              className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-3.5 py-2.5 text-sm font-bold text-slate-800 hover:bg-slate-100"
            >
              <ArrowLeft size={17} /> Back
            </button>
            <div>
              <h2 className="text-2xl font-black text-slate-900">Bulk Add Payable Invoices</h2>
              <p className="text-sm text-slate-600 mt-0.5">
                Upload your file to validate and process bulk invoices.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="inline-flex items-center gap-2 rounded-lg bg-slate-900 px-4 py-2.5 text-sm font-bold text-white hover:bg-slate-700"
          >
            <X size={18} /> Close
          </button>
        </header>

        <main className="flex-1 p-6 space-y-5 max-w-[1500px] w-full mx-auto">
          <section className="rounded-xl border border-indigo-200 bg-indigo-50 p-5">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
              <div>
                <h3 className="text-lg font-black text-slate-900">File format requirements</h3>
                <p className="text-sm text-slate-700 mt-1">
                  Use the exact columns below. Column order is recommended but not mandatory; column names are matched case-insensitively.
                </p>
              </div>
              <DownloadTemplate />
            </div>
            <div className="mt-4 overflow-x-auto rounded-lg border border-indigo-200 bg-white">
              <table className="w-full text-sm">
                <thead className="bg-slate-100 text-slate-800">
                  <tr>
                    <th className="px-3 py-2.5 text-left font-black">Column</th>
                    <th className="px-3 py-2.5 text-left font-black">Required</th>
                    <th className="px-3 py-2.5 text-left font-black">Example</th>
                  </tr>
                </thead>
                <tbody>
                  {BULK_PAYABLE_COLUMN_GUIDE.map((column) => (
                    <tr key={column.key} className="border-t border-slate-200">
                      <td className="px-3 py-2 font-mono font-bold text-indigo-700">{column.key}</td>
                      <td className="px-3 py-2 font-bold text-emerald-700">Yes</td>
                      <td className="px-3 py-2 text-slate-700">{column.example}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          <section className="rounded-xl border border-slate-200 bg-white shadow-sm p-6">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div>
                <h3 className="text-lg font-black text-slate-900">1. Select file</h3>
                <p className="text-sm text-slate-600 mt-1">Accepted: .xlsx, .xls, .csv</p>
              </div>
              <button
                type="button"
                onClick={() => inputRef.current?.click()}
                className="inline-flex items-center justify-center gap-2 rounded-lg bg-indigo-600 px-5 py-3 text-sm font-black text-white shadow-sm hover:bg-indigo-700"
              >
                <Upload size={18} /> Choose Excel / CSV
              </button>
              <input
                ref={inputRef}
                hidden
                type="file"
                accept=".xlsx,.xls,.csv"
                onChange={(event) => handleFile(event.target.files?.[0])}
              />
            </div>

            {file && (
              <div className="mt-5 rounded-lg border border-slate-200 bg-slate-50 p-4 flex items-center gap-3">
                <FileSpreadsheet className="text-emerald-600" size={22} />
                <div className="min-w-0 flex-1">
                  <div className="font-bold text-slate-900 truncate">{file.name}</div>
                  <div className="text-xs text-slate-600">{Math.round(file.size / 1024)} KB</div>
                </div>
                {parsing && <RefreshCw size={18} className="animate-spin text-indigo-600" />}
                {!parsing && rows.length > 0 && <CheckCircle2 size={20} className="text-emerald-600" />}
              </div>
            )}

            {parseError && (
              <div className="mt-4 rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm font-semibold text-rose-700">
                <AlertCircle className="inline mr-2" size={17} />
                {parseError}
              </div>
            )}
          </section>

          {rows.length > 0 && (
            <section className="rounded-xl border border-slate-200 bg-white shadow-sm overflow-hidden">
              <div className="px-6 py-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                <div>
                  <h3 className="text-lg font-black text-slate-900">2. Review payable data</h3>
                  <p className="text-sm text-slate-600">
                    {rows.length} rows data. Showing first {previewRows.length} rows for review.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={handleUpload}
                  disabled={uploading}
                  className="inline-flex items-center justify-center gap-2 rounded-lg bg-emerald-600 px-5 py-3 text-sm font-black text-white hover:bg-emerald-700 disabled:opacity-50"
                >
                  {uploading ? <RefreshCw size={18} className="animate-spin" /> : <CheckCircle2 size={18} />}
                  {uploading ? "Uploading..." : "Upload The Data"}
                </button>
              </div>
              <div className="overflow-x-auto">
                <table className="min-w-[1100px] w-full text-sm">
                  <thead className="bg-slate-100 text-slate-800">
                    <tr>
                      {BULK_PAYABLE_COLUMN_GUIDE.map((column) => (
                        <th key={column.key} className="px-3 py-3 text-left font-black whitespace-nowrap">
                          {column.key}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {previewRows.map((row) => (
                      <tr key={row.__sourceRow} className="border-t border-slate-200">
                        {BULK_PAYABLE_COLUMN_GUIDE.map((column) => (
                          <td key={column.key} className="px-3 py-3 text-slate-700 whitespace-nowrap">
                            {String(row[column.key] ?? "")}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>
          )}

          {uploadError && (
            <div className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm font-semibold text-rose-700">
              <AlertCircle className="inline mr-2" size={17} />
              {uploadError}
            </div>
          )}

          {result && (
            <section className="rounded-xl border border-slate-200 bg-white shadow-sm p-6 space-y-4">
              <h3 className="text-lg font-black text-slate-900">3. Bulk Import Results</h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="rounded-lg bg-slate-50 border border-slate-200 p-4">
                  <div className="text-xs font-bold uppercase text-slate-500">Received</div>
                  <div className="text-2xl font-black text-slate-900 mt-1">
                    {result.summary?.totalReceived ?? rows.length}
                  </div>
                </div>
                <div className="rounded-lg bg-emerald-50 border border-emerald-200 p-4">
                  <div className="text-xs font-bold uppercase text-emerald-700">Created</div>
                  <div className="text-2xl font-black text-emerald-700 mt-1">
                    {result.summary?.successfullyInserted ?? 0}
                  </div>
                </div>
                <div className="rounded-lg bg-rose-50 border border-rose-200 p-4">
                  <div className="text-xs font-bold uppercase text-rose-700">Failed</div>
                  <div className="text-2xl font-black text-rose-700 mt-1">
                    {result.summary?.failedCount ?? failedItemsList.length}
                  </div>
                </div>
              </div>

              {failedItemsList.length > 0 && (
                <div className="mt-5 rounded-xl border border-rose-200 bg-rose-50/50 p-4">
                  <div className="flex items-center gap-2 mb-3 text-rose-800 font-black">
                    <AlertTriangle size={18} />
                    <span>Failed Invoices Log ({failedItemsList.length} items requiring attention)</span>
                  </div>
                  <div className="overflow-x-auto bg-white rounded-lg border border-rose-200">
                    <table className="min-w-full text-sm">
                      <thead className="bg-rose-100/70 text-rose-900">
                        <tr>
                          <th className="px-3 py-2 text-left font-black">Row</th>
                          <th className="px-3 py-2 text-left font-black">Invoice No</th>
                          <th className="px-3 py-2 text-left font-black">GRN</th>
                          <th className="px-3 py-2 text-left font-black">Supplier</th>
                          <th className="px-3 py-2 text-left font-black">Validation Error Logs</th>
                        </tr>
                      </thead>
                      <tbody>
                        {failedItemsList.map((item) => (
                          <tr key={item.index} className="border-t border-rose-100 hover:bg-rose-50/30">
                            <td className="px-3 py-2.5 font-bold text-slate-700">#{item.index}</td>
                            <td className="px-3 py-2.5 font-mono font-semibold text-slate-900">
                              {item.invoiceNumber}
                            </td>
                            <td className="px-3 py-2.5 font-mono text-slate-700">{item.grnNumber}</td>
                            <td className="px-3 py-2.5 text-slate-700">{item.supplierName || "N/A"}</td>
                            <td className="px-3 py-2.5 text-rose-700 font-medium">
                              {Array.isArray(item.errors) ? (
                                <ul className="list-disc list-inside space-y-1">
                                  {item.errors.map((err, i) => (
                                    <li key={i}>{err}</li>
                                  ))}
                                </ul>
                              ) : (
                                String(item.errors || "")
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </section>
          )}
        </main>
      </div>
    </div>
  );
}

export default function AddPayableDialog({ isOpen, onClose, onSuccess }) {
  const { showNotification } = useNotification();
  const [formData, setFormData] = useState(initialFormState);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [bulkMode, setBulkMode] = useState(false);

  useEffect(() => {
    if (!isOpen) {
      setFormData(initialFormState);
      setError(null);
      setBulkMode(false);
    }
  }, [isOpen]);

  useEffect(() => {
    const sub = parseFloat(formData.subTotal);
    const gst = parseFloat(formData.gstRate);
    if (!Number.isNaN(sub) && !Number.isNaN(gst) && sub >= 0) {
      const calculatedGst = Math.round(sub * (gst / 100) * 100) / 100;
      const total = Math.round((sub + calculatedGst) * 100) / 100;
      setFormData((prev) => ({ ...prev, totalAmount: total.toFixed(2) }));
    } else if (formData.subTotal === "") {
      setFormData((prev) => ({ ...prev, totalAmount: "" }));
    }
  }, [formData.subTotal, formData.gstRate]);

  if (!isOpen) return null;

  if (bulkMode) {
    return <BulkUploadWorkspace onBack={() => setBulkMode(false)} onClose={onClose} onSuccess={onSuccess} />;
  }

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleDecimalChange = (event) => {
    const { name, value } = event.target;
    if (value === "") return setFormData((prev) => ({ ...prev, [name]: "" }));
    if (!/^\d*\.?\d{0,2}$/.test(value)) return;
    if (["gstRate", "tdsRate"].includes(name) && Number(value) > 100) return;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError(null);
    if (!formData.invoiceNumber.trim()) return setError("Invoice Number is required.");
    if (!formData.grnNumber.trim()) return setError("GRN Number is required.");
    if (!formData.supplierName.trim()) return setError("Supplier Name is required.");
    if (!formData.invoiceDate) return setError("Invoice Date is required.");
    if (formData.subTotal === "" || Number(formData.subTotal) < 0) return setError("Sub Total must be a valid non-negative number.");
    if (Number(formData.gstRate) > 100 || Number(formData.tdsRate) > 100) return setError("GST and TDS rates cannot exceed 100%.");

    try {
      setLoading(true);
      const response = await payablesApi.create({
        invoiceNumber: formData.invoiceNumber.trim(),
        grnNumber: formData.grnNumber.trim(),
        supplierName: formData.supplierName.trim(),
        invoiceDate: formData.invoiceDate,
        subTotal: Number(formData.subTotal),
        gstRate: Number(formData.gstRate || 0),
        totalAmount: Number(formData.totalAmount),
        tdsRate: Number(formData.tdsRate || 0),
      });
      const successMessage = response.data?.message || "Payable created successfully.";
      showNotification(successMessage, "success");
      onSuccess?.(successMessage);
      onClose();
    } catch (err) {
      const errMsg = err.response?.data?.message || "Failed to create payable invoice.";
      setError(errMsg);
      showNotification(errMsg, "error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed top-14 left-64 right-0 bottom-0 z-50 bg-slate-50 overflow-y-auto">
      <div className="min-h-full flex flex-col">
        <header className="sticky top-0 z-10 bg-white border-b border-slate-200 shadow-sm px-6 py-4 flex items-center justify-between gap-4">
          <div>
            <h2 className="text-2xl font-black text-slate-900">Add Payable Invoice</h2>
            <p className="text-sm text-slate-600 mt-0.5">Create one supplier invoice or switch to bulk upload.</p>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setBulkMode(true)}
              className="inline-flex items-center gap-2 rounded-lg bg-indigo-600 px-4 py-2.5 text-sm font-black text-white hover:bg-indigo-700"
            >
              <FileSpreadsheet size={18} /> Bulk Payable Add
            </button>
            <button
              type="button"
              onClick={onClose}
              className="inline-flex items-center gap-2 rounded-lg bg-slate-900 px-4 py-2.5 text-sm font-black text-white hover:bg-slate-700"
            >
              <X size={18} /> Close
            </button>
          </div>
        </header>

        <main className="flex-1 p-6">
          <div className="max-w-5xl mx-auto rounded-xl border border-slate-200 bg-white shadow-sm p-6 md:p-8">
            {error && (
              <div className="mb-5 rounded-lg border border-rose-200 bg-rose-50 px-4 py-3 text-sm font-bold text-rose-700">
                {error}
              </div>
            )}
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                {[
                  ["invoiceNumber", "Invoice Number *", "INV-2026-001"],
                  ["grnNumber", "GRN Number *", "GRN-9942"],
                  ["supplierName", "Supplier Name *", "ABC Industries"],
                  ["invoiceDate", "Invoice Date *", ""],
                ].map(([name, label, placeholder]) => (
                  <label key={name} className="block">
                    <span className="block text-sm font-black text-slate-800 mb-2">{label}</span>
                    <input
                      type={name === "invoiceDate" ? "date" : "text"}
                      name={name}
                      value={formData[name]}
                      onChange={handleChange}
                      placeholder={placeholder}
                      className="w-full rounded-lg border border-slate-300 bg-white px-4 py-3 text-base font-semibold text-slate-900 outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100"
                      required
                    />
                  </label>
                ))}
                <label className="block">
                  <span className="block text-sm font-black text-slate-800 mb-2">Sub Total (₹) *</span>
                  <input
                    name="subTotal"
                    value={formData.subTotal}
                    onChange={handleDecimalChange}
                    inputMode="decimal"
                    className="w-full rounded-lg border border-slate-300 px-4 py-3 text-base font-semibold font-mono text-slate-900 outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100"
                    required
                  />
                </label>
                <label className="block">
                  <span className="block text-sm font-black text-slate-800 mb-2">GST Rate (%) *</span>
                  <input
                    name="gstRate"
                    value={formData.gstRate}
                    onChange={handleDecimalChange}
                    inputMode="decimal"
                    className="w-full rounded-lg border border-slate-300 px-4 py-3 text-base font-semibold font-mono text-slate-900 outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100"
                    required
                  />
                </label>
                <label className="block">
                  <span className="block text-sm font-black text-slate-800 mb-2">Total Amount (₹)</span>
                  <input
                    name="totalAmount"
                    value={formData.totalAmount}
                    readOnly
                    className="w-full rounded-lg border border-slate-200 bg-slate-100 px-4 py-3 text-base font-black font-mono text-slate-900"
                  />
                </label>
                <label className="block">
                  <span className="block text-sm font-black text-slate-800 mb-2">TDS Rate (%) *</span>
                  <input
                    name="tdsRate"
                    value={formData.tdsRate}
                    onChange={handleDecimalChange}
                    inputMode="decimal"
                    className="w-full rounded-lg border border-slate-300 px-4 py-3 text-base font-semibold font-mono text-slate-900 outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100"
                    required
                  />
                </label>
              </div>

              <div className="rounded-lg border border-slate-200 bg-slate-50 p-5">
                <div className="text-sm font-black text-slate-900">Calculated invoice summary</div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
                  <div>
                    <div className="text-xs font-bold text-slate-500">Sub Total</div>
                    <div className="text-lg font-black text-slate-900 mt-1">
                      {formatMoney(formData.subTotal)}
                    </div>
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-500">GST</div>
                    <div className="text-lg font-black text-slate-900 mt-1">
                      {formatMoney(Number(formData.totalAmount || 0) - Number(formData.subTotal || 0))}
                    </div>
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-500">Total</div>
                    <div className="text-lg font-black text-indigo-700 mt-1">
                      {formatMoney(formData.totalAmount)}
                    </div>
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-500">TDS Rate</div>
                    <div className="text-lg font-black text-slate-900 mt-1">
                      {Number(formData.tdsRate || 0)}%
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex flex-col-reverse sm:flex-row sm:justify-end gap-3 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={onClose}
                  className="rounded-lg border border-slate-300 bg-white px-6 py-3 text-sm font-black text-slate-800 hover:bg-slate-100"
                >
                  Close
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="rounded-lg bg-emerald-600 px-7 py-3 text-sm font-black text-white hover:bg-emerald-700 disabled:opacity-50"
                >
                  {loading ? "Saving..." : "Create Payable Invoice"}
                </button>
              </div>
            </form>
          </div>
        </main>
      </div>
    </div>
  );
}