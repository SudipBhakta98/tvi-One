// src/pages/PayablesPage.jsx

import React, { useState, useEffect, useMemo, useRef } from "react";
import { useSearchParams } from "react-router-dom";

import { payablesApi } from "../api.js";
import { usePayables } from "../contexts/PayableContext.jsx";
import PayablesInvoiceDialog from "../components/payableComponents/PayablesInvoiceDialog.jsx";
import AddPayableDialog from "../components/payableComponents/AddPayableDialog.jsx";

// ============================================================
// HELPERS
// ============================================================

const formatCurrency = (amount) =>
  "₹" + Math.round(Number(amount) || 0).toLocaleString("en-IN");

const formatDateString = (rawDate) => {
  if (!rawDate) return "—";
  return String(rawDate);
};

const MONTH_NAMES = [
  "Jan", "Feb", "Mar", "Apr", "May", "Jun",
  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
];

// Helper to reliably parse DD-MM-YYYY or ISO date strings
const parseDateString = (dateStr) => {
  if (!dateStr) return null;
  const str = String(dateStr).trim();

  // Handle DD-MM-YYYY format
  if (/^\d{2}-\d{2}-\d{4}$/.test(str)) {
    const [day, month, year] = str.split("-");
    return {
      year,
      month, // "08"
      key: `${year}-${month}`, // "2026-08"
      label: `${MONTH_NAMES[parseInt(month, 10) - 1]} ${year}`, // "Aug 2026"
    };
  }

  // Handle YYYY-MM-DD or standard ISO strings
  const parsed = new Date(str);
  if (!Number.isNaN(parsed.getTime())) {
    const year = String(parsed.getFullYear());
    const month = String(parsed.getMonth() + 1).padStart(2, "0");
    return {
      year,
      month,
      key: `${year}-${month}`,
      label: `${MONTH_NAMES[parsed.getMonth()]} ${year}`,
    };
  }

  return null;
};

// ============================================================
// EXCEL-STYLE MULTI-SELECT DROPDOWN FILTER
// ============================================================

function ExcelFilterDropdown({ title, options, selectedValues, onChange }) {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const dropdownRef = useRef(null);

  // Close dropdown on click outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const filteredOptions = useMemo(() => {
    return options.filter((opt) =>
      opt.label.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [options, searchTerm]);

  const isAllSelected =
    options.length > 0 && selectedValues.length === options.length;

  const handleToggleAll = () => {
    if (isAllSelected) {
      onChange([]);
    } else {
      onChange(options.map((o) => o.value));
    }
  };

  const handleToggleOption = (val) => {
    if (selectedValues.includes(val)) {
      onChange(selectedValues.filter((v) => v !== val));
    } else {
      onChange([...selectedValues, val]);
    }
  };

  const activeCount = selectedValues.length;
  const isFiltered = activeCount > 0 && activeCount < options.length;

  return (
    <div className="relative inline-block text-left" ref={dropdownRef}>
      <button
        type="button"
        onClick={() => setIsOpen((prev) => !prev)}
        className={`inline-flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium border transition ${
          isFiltered
            ? "bg-indigo-50 border-indigo-300 text-indigo-700 font-semibold"
            : "bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100"
        }`}
      >
        <span>{title}</span>
        {isFiltered && (
          <span className="px-1.5 py-0.2 rounded-full bg-indigo-600 text-white text-[10px]">
            {activeCount}
          </span>
        )}
        <svg
          className="w-3.5 h-3.5 text-slate-400"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
        </svg>
      </button>

      {isOpen && (
        <div className="absolute left-0 mt-2 w-64 rounded-xl bg-white border border-slate-200 shadow-xl z-50 p-3 space-y-2 text-xs">
          {/* Search Box */}
          <input
            type="text"
            placeholder={`Search ${title.toLowerCase()}...`}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-50 border border-slate-200 rounded-md px-2.5 py-1.5 text-xs text-slate-800 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
          />

          {/* Controls */}
          <div className="flex items-center justify-between border-b border-slate-100 pb-2 pt-1 text-[11px]">
            <label className="flex items-center gap-2 cursor-pointer font-semibold text-slate-700">
              <input
                type="checkbox"
                checked={isAllSelected}
                onChange={handleToggleAll}
                className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
              />
              <span>(Select All)</span>
            </label>
            {activeCount > 0 && (
              <button
                type="button"
                onClick={() => onChange([])}
                className="text-rose-600 hover:underline font-medium"
              >
                Clear
              </button>
            )}
          </div>

          {/* Options List */}
          <div className="max-h-48 overflow-y-auto space-y-1 pr-1">
            {filteredOptions.length === 0 ? (
              <div className="text-slate-400 text-center py-2">No options found</div>
            ) : (
              filteredOptions.map((opt) => {
                const checked = selectedValues.includes(opt.value);
                return (
                  <label
                    key={opt.value}
                    className="flex items-center gap-2 px-1.5 py-1 rounded hover:bg-slate-50 cursor-pointer text-slate-700"
                  >
                    <input
                      type="checkbox"
                      checked={checked}
                      onChange={() => handleToggleOption(opt.value)}
                      className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                    />
                    <span className="truncate">{opt.label}</span>
                  </label>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  );
}

// ============================================================
// UI BADGES
// ============================================================

function StatusBadge({ status }) {
  const normalizedStatus = String(status || "").toLowerCase();

  const badgeStyles = {
    paid: "bg-emerald-50 text-emerald-700 border-emerald-200",
    partial: "bg-amber-50 text-amber-700 border-amber-200",
    unpaid: "bg-rose-50 text-rose-700 border-rose-200",
  };

  return (
    <span
      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold border ${
        badgeStyles[normalizedStatus] || "bg-slate-100 text-slate-600 border-slate-200"
      }`}
    >
      <span
        className={`w-1.5 h-1.5 rounded-full mr-1.5 ${
          normalizedStatus === "paid"
            ? "bg-emerald-500"
            : normalizedStatus === "partial"
            ? "bg-amber-500"
            : "bg-rose-500"
        }`}
      />
      <span className="capitalize">{status || "Unknown"}</span>
    </span>
  );
}

function DueDaysBadge({ status, dueDays }) {
  const normalizedStatus = String(status || "").toLowerCase();

  if (normalizedStatus === "paid" || dueDays === undefined || dueDays === null) {
    return <span className="text-slate-400">—</span>;
  }

  const numericDueDays = Number(dueDays);

  const badgeStyles =
    numericDueDays >= 15
      ? "text-emerald-700 bg-emerald-50 border-emerald-200"
      : numericDueDays >= 0
      ? "text-amber-700 bg-amber-50 border-amber-200"
      : "text-rose-700 bg-rose-50 border-rose-200 font-bold";

  return (
    <span className={`inline-block px-2 py-0.5 rounded border text-xs whitespace-nowrap ${badgeStyles}`}>
      {numericDueDays >= 0
        ? `${numericDueDays} days left`
        : `${Math.abs(numericDueDays)} days overdue`}
    </span>
  );
}

// ============================================================
// MAIN PAGE
// ============================================================

export default function PayablesPage() {
  const {
    analyticsData,
    storeAnalytics,
    searchResults,
    storeSearchResults,
    clearSearch,
    searchState: contextSearchState,
    updateSearchState: contextUpdateSearchState,
  } = usePayables();

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [searchParams, setSearchParams] = useSearchParams();

  const [localSearchState, setLocalSearchState] = useState({
    search: "",
    page: 1,
    limit: 10,
    loading: false,
    error: null,
  });

  const searchState = contextSearchState || localSearchState;

  const updateSearchState = (updates) => {
    if (contextUpdateSearchState) {
      contextUpdateSearchState(updates);
    } else {
      setLocalSearchState((prev) => ({ ...prev, ...updates }));
    }
  };

  useEffect(() => {
    setIsDialogOpen(searchParams.get("create") === "1");
  }, [searchParams]);

  const closeCreatePayable = () => {
    setIsDialogOpen(false);
    const nextParams = new URLSearchParams(searchParams);
    nextParams.delete("create");
    setSearchParams(nextParams, { replace: true });
  };

  // Checkbox Selection Filters
  const [selectedSuppliers, setSelectedSuppliers] = useState([]);
  const [selectedStatuses, setSelectedStatuses] = useState([]);
  const [selectedMonths, setSelectedMonths] = useState([]);

  const [searchInput, setSearchInput] = useState("");
  const [activeInvoice, setActiveInvoice] = useState(null);

  // Normalize Analytics Data
  const totalInvoicesList = useMemo(() => {
    return (analyticsData?.data || []).map((item) => ({
      ...item,
      _id: item._id || item.id || null,
      invoice_number: item.invoiceNumber ?? item.invoice_number ?? "",
      grn_number: item.grnNumber ?? item.grn_number ?? "",
      supplier_name: (item.supplierName ?? item.supplier_name ?? "").trim(),
      invoice_date: item.invoiceDate ?? item.invoice_date ?? null,
      sub_total: Number(item.subTotal ?? item.sub_total ?? 0),
      gst_rate: Number(item.gstRate ?? item.gst_rate ?? 0),
      gst_amount: Number(item.gstAmount ?? item.gst_amount ?? 0),
      tds_rate: Number(item.tdsRate ?? item.tds_rate ?? 0),
      tds_amount: Number(item.tdsAmount ?? item.tds_amount ?? 0),
      total_amount: Number(item.totalAmount ?? item.total_amount ?? 0),
      gross_payable_amount: Number(
        item.grossPayableAmount ?? item.gross_payable_amount ?? 0
      ),
      debit_amount: Number(item.debitAmount ?? item.debit_amount ?? 0),
      actual_payable_amount: Number(
        item.actualPayableAmount ?? item.actual_payable_amount ?? 0
      ),
      paid_amount: Number(item.paidAmount ?? item.paid_amount ?? 0),
      outstanding: Number(item.outstanding || 0),
      status: item.status || "unpaid",
      due_days: item.dueDays ?? item.due_days ?? null,
      is_overdue: item.isOverdue ?? item.is_overdue ?? false,
    }));
  }, [analyticsData?.data]);

  const searchInvoicesList = useMemo(() => {
    return (searchResults?.searchPayables || []).map((item) => ({
      ...item,
      _id: item._id || item.id || null,
      invoice_number: item.invoiceNumber ?? item.invoice_number ?? "",
      grn_number: item.grnNumber ?? item.grn_number ?? "",
      supplier_name: (item.supplierName ?? item.supplier_name ?? "").trim(),
      invoice_date: item.invoiceDate ?? item.invoice_date ?? null,
      sub_total: Number(item.subTotal ?? item.sub_total ?? 0),
      gst_rate: Number(item.gstRate ?? item.gst_rate ?? 0),
      gst_amount: Number(item.gstAmount ?? item.gst_amount ?? 0),
      tds_rate: Number(item.tdsRate ?? item.tds_rate ?? 0),
      tds_amount: Number(item.tdsAmount ?? item.tds_amount ?? 0),
      total_amount: Number(item.totalAmount ?? item.total_amount ?? 0),
      gross_payable_amount: Number(
        item.grossPayableAmount ?? item.gross_payable_amount ?? 0
      ),
      debit_amount: Number(item.debitAmount ?? item.debit_amount ?? 0),
      actual_payable_amount: Number(
        item.actualPayableAmount ?? item.actual_payable_amount ?? 0
      ),
      paid_amount: Number(item.paidAmount ?? item.paid_amount ?? 0),
      outstanding: Number(item.outstanding || 0),
      status: item.status || "unpaid",
      due_days: item.dueDays ?? item.due_days ?? null,
      is_overdue: item.isOverdue ?? item.is_overdue ?? false,
    }));
  }, [searchResults?.searchPayables]);

  const loadAnalytics = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await payablesApi.getAnalytics([]);
      if (response.data?.success) {
        storeAnalytics(response.data);
      } else {
        throw new Error(
          response.data?.message || "Failed to load payable analytics."
        );
      }
    } catch (err) {
      setError(
        err.response?.data?.message ||
          err.message ||
          "Failed to load payables analytics."
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAnalytics();
  }, []);

  const baseInvoicesList = searchInput.trim()
    ? searchInvoicesList
    : totalInvoicesList;

  // Options Extracted from Dataset
  const supplierOptions = useMemo(() => {
    const list = [
      ...new Set(
        baseInvoicesList
          .map((i) => i.supplier_name)
          .filter(Boolean)
      ),
    ].sort();
    return list.map((sup) => ({ value: sup, label: sup }));
  }, [baseInvoicesList]);

  const monthOptions = useMemo(() => {
    const monthMap = new Map();
    baseInvoicesList.forEach((invoice) => {
      const parsed = parseDateString(invoice.invoice_date);
      if (parsed) {
        monthMap.set(parsed.key, parsed.label);
      }
    });

    return Array.from(monthMap.entries())
      .map(([key, label]) => ({ value: key, label }))
      .sort((a, b) => b.value.localeCompare(a.value));
  }, [baseInvoicesList]);

  const statusOptions = [
    { value: "paid", label: "Paid" },
    { value: "partial", label: "Partial" },
    { value: "unpaid", label: "Unpaid" },
  ];

  // Initialize Checkbox Selections Default to ALL
  useEffect(() => {
    if (supplierOptions.length > 0 && selectedSuppliers.length === 0) {
      setSelectedSuppliers(supplierOptions.map((o) => o.value));
    }
  }, [supplierOptions]);

  useEffect(() => {
    if (monthOptions.length > 0 && selectedMonths.length === 0) {
      setSelectedMonths(monthOptions.map((o) => o.value));
    }
  }, [monthOptions]);

  useEffect(() => {
    if (selectedStatuses.length === 0) {
      setSelectedStatuses(statusOptions.map((o) => o.value));
    }
  }, []);

  // Filter Logic
  const filteredInvoices = useMemo(() => {
    return baseInvoicesList.filter((invoice) => {
      const matchesSupplier =
        selectedSuppliers.length === 0 ||
        selectedSuppliers.includes(invoice.supplier_name);

      const matchesStatus =
        selectedStatuses.length === 0 ||
        selectedStatuses.includes(String(invoice.status).toLowerCase());

      const parsedDate = parseDateString(invoice.invoice_date);
      const matchesMonth =
        selectedMonths.length === 0 ||
        (parsedDate && selectedMonths.includes(parsedDate.key));

      return matchesSupplier && matchesStatus && matchesMonth;
    });
  }, [baseInvoicesList, selectedSuppliers, selectedStatuses, selectedMonths]);

  const computedMetrics = useMemo(() => {
    const defaultAccumulator = {
      totalPayable: 0,
      totalPaid: 0,
      paidCount: 0,
      unpaidCount: 0,
      partialCount: 0,
      groups: {},
    };

    return filteredInvoices.reduce((acc, invoice) => {
      acc.totalPayable += Number(invoice.actual_payable_amount) || 0;
      acc.totalPaid += Number(invoice.paid_amount) || 0;

      const status = String(invoice.status || "").toLowerCase();

      if (status === "paid") acc.paidCount++;
      else if (status === "unpaid") acc.unpaidCount++;
      else if (status === "partial") acc.partialCount++;

      const groupKey = invoice.supplier_name || "Uncategorized";

      if (!acc.groups[groupKey]) {
        acc.groups[groupKey] = [];
      }

      acc.groups[groupKey].push(invoice);

      return acc;
    }, defaultAccumulator);
  }, [filteredInvoices]);

  const resetAllFilters = () => {
    setSearchInput("");
    clearSearch();
    setSelectedSuppliers(supplierOptions.map((o) => o.value));
    setSelectedMonths(monthOptions.map((o) => o.value));
    setSelectedStatuses(statusOptions.map((o) => o.value));
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px] bg-slate-50 text-slate-500 font-medium">
        <div className="flex items-center gap-3">
          <div className="w-5 h-5 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin" />
          <span>Loading payables...</span>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-[400px] bg-slate-50 text-rose-600 font-medium">
        {error}
      </div>
    );
  }

  const kpiCardsConfig = [
    {
      label: "Total Payable",
      value: computedMetrics.totalPayable,
      sub: `${filteredInvoices.length} total records`,
      color: "text-slate-900",
      border: "border-l-indigo-500",
    },
    {
      label: "Total Paid",
      value: computedMetrics.totalPaid,
      sub: `${
        computedMetrics.totalPayable > 0
          ? ((computedMetrics.totalPaid / computedMetrics.totalPayable) * 100).toFixed(1)
          : 0
      }% completion`,
      color: "text-emerald-600",
      border: "border-l-emerald-500",
    },
    {
      label: "Outstanding",
      value: computedMetrics.totalPayable - computedMetrics.totalPaid,
      sub: "Balance remaining",
      color: "text-rose-600",
      border: "border-l-rose-500",
    },
    {
      label: "Fully Paid",
      value: computedMetrics.paidCount,
      sub: "Invoices settled",
      color: "text-emerald-600",
      border: "border-l-emerald-400",
      rawValue: true,
    },
    {
      label: "Unpaid",
      value: computedMetrics.unpaidCount,
      sub: "Awaiting payment",
      color: "text-rose-600",
      border: "border-l-rose-400",
      rawValue: true,
    },
    {
      label: "Partial",
      value: computedMetrics.partialCount,
      sub: "Partially settled",
      color: "text-amber-600",
      border: "border-l-amber-400",
      rawValue: true,
    },
  ];

  return (
    <div className="min-h-screen bg-slate-50/50 text-slate-900 px-4 max-w-[1600px] mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-200 pb-5">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">Payables</h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Manage vendor invoices, payments, and financial tracking
          </p>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
        {kpiCardsConfig.map((card, idx) => (
          <div
            key={idx}
            className={`p-4 rounded-xl bg-white border border-slate-200 border-l-4 ${card.border} shadow-sm flex flex-col justify-between`}
          >
            <span className="text-xs font-bold tracking-wider text-slate-400 uppercase">
              {card.label}
            </span>
            <div className={`my-2 text-2xl font-bold tracking-tight ${card.color}`}>
              {card.rawValue ? card.value : formatCurrency(card.value)}
            </div>
            <span className="text-xs text-slate-500">{card.sub}</span>
          </div>
        ))}
      </div>

      {/* Excel-Style Filters Control Bar */}
      <div className="flex flex-wrap items-center gap-3 p-3 rounded-xl bg-white border border-slate-200 shadow-sm">
        {/* Search Bar */}
        <div className="relative flex-1 min-w-[240px]">
          <input
            type="text"
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            placeholder="Search invoice number, GRN, supplier..."
            className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-3 pr-8 py-2 text-xs text-slate-800 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition"
          />
          {searchInput && (
            <button
              type="button"
              onClick={() => setSearchInput("")}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs font-semibold"
            >
              ✕
            </button>
          )}
        </div>

        {/* Excel Checkbox Filters */}
        <ExcelFilterDropdown
          title="Supplier"
          options={supplierOptions}
          selectedValues={selectedSuppliers}
          onChange={setSelectedSuppliers}
        />

        <ExcelFilterDropdown
          title="Month"
          options={monthOptions}
          selectedValues={selectedMonths}
          onChange={setSelectedMonths}
        />

        <ExcelFilterDropdown
          title="Status"
          options={statusOptions}
          selectedValues={selectedStatuses}
          onChange={setSelectedStatuses}
        />

        <button
          type="button"
          onClick={resetAllFilters}
          className="px-3 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 border border-slate-200 rounded-lg hover:bg-slate-50 transition"
        >
          Reset Filters
        </button>
      </div>

      {/* Ledger Table */}
      <div className="overflow-hidden border border-slate-200 rounded-xl bg-white shadow-sm">
        <div className="overflow-x-auto">
          {filteredInvoices.length === 0 ? (
            <div className="text-center py-12 text-slate-400 font-medium text-sm">
              No invoice statements match the selected filters.
            </div>
          ) : (
            <table className="w-full text-xs text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider">
                  <th className="px-4 py-3 font-mono">Invoice ID</th>
                  <th className="px-4 py-3">Supplier Name</th>
                  <th className="px-4 py-3">Invoice Date</th>
                  <th className="px-4 py-3 text-right">Net Amount</th>
                  <th className="px-4 py-3 text-right">Paid Amount</th>
                  <th className="px-4 py-3 text-right">Outstanding</th>
                  <th className="px-4 py-3 text-center">Status</th>
                  <th className="px-4 py-3 text-center">Due Timeline</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {Object.entries(computedMetrics.groups).flatMap(
                  ([supplierName, groupInvoices]) => {
                    const groupPayable = groupInvoices.reduce(
                      (sum, i) => sum + (i.actual_payable_amount || 0),
                      0
                    );
                    const groupPaid = groupInvoices.reduce(
                      (sum, i) => sum + (i.paid_amount || 0),
                      0
                    );

                    const invoiceRows = groupInvoices.map((invoice, idx) => {
                      const rowKey =
                        invoice._id ||
                        invoice.id ||
                        `inv-${supplierName}-${invoice.invoice_number}-${idx}`;

                      return (
                        <tr
                          key={rowKey}
                          
                          onClick={() => {
                            setActiveInvoice(invoice)
                          console.log(invoice)}}
                          className="cursor-pointer hover:bg-indigo-50/30 transition-colors group"
                        >
                          <td className="px-4 py-2.5 font-mono text-slate-600 font-medium group-hover:text-indigo-600">
                            {invoice.invoice_number}
                          </td>
                          <td className="px-4 py-2.5 font-semibold text-slate-800">
                            {supplierName}
                          </td>
                          <td className="px-4 py-2.5 text-slate-600 whitespace-nowrap">
                            {formatDateString(invoice.invoice_date)}
                          </td>
                          <td className="px-4 py-2.5 text-right font-medium text-slate-900">
                            {formatCurrency(invoice.actual_payable_amount)}
                          </td>
                          <td className="px-4 py-2.5 text-right font-semibold text-emerald-600">
                            {formatCurrency(invoice.paid_amount)}
                          </td>
                          <td
                            className={`px-4 py-2.5 text-right font-semibold ${
                              invoice.outstanding > 0 ? "text-rose-600" : "text-slate-400"
                            }`}
                          >
                            {formatCurrency(invoice.outstanding)}
                          </td>
                          <td className="px-4 py-2.5 text-center whitespace-nowrap">
                            <StatusBadge status={invoice.status} />
                          </td>
                          <td className="px-4 py-2.5 text-center whitespace-nowrap">
                            <DueDaysBadge
                              status={invoice.status}
                              dueDays={invoice.due_days}
                            />
                          </td>
                        </tr>
                      );
                    });

                    const subtotalRow = (
                      <tr
                        key={`${supplierName}-subtotal`}
                        className="bg-slate-50/80 font-semibold border-b border-slate-200 text-xs"
                      >
                        <td colSpan={3} className="px-4 py-2 text-slate-500 italic">
                          Subtotal for {supplierName} ({groupInvoices.length} invoices)
                        </td>
                        <td className="px-4 py-2 text-right text-slate-900 font-bold">
                          {formatCurrency(groupPayable)}
                        </td>
                        <td className="px-4 py-2 text-right text-emerald-600 font-bold">
                          {formatCurrency(groupPaid)}
                        </td>
                        <td className="px-4 py-2 text-right text-rose-600 font-bold">
                          {formatCurrency(groupPayable - groupPaid)}
                        </td>
                        <td colSpan={2} className="px-4 py-2 text-right text-indigo-600 font-bold pr-6">
                          {groupPayable > 0
                            ? ((groupPaid / groupPayable) * 100).toFixed(1)
                            : 0}
                          % paid
                        </td>
                      </tr>
                    );

                    return [...invoiceRows, subtotalRow];
                  }
                )}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {/* Dialogs */}
      {activeInvoice && (
        <PayablesInvoiceDialog
          invoice={activeInvoice}
          onClose={() => setActiveInvoice(null)}
        />
      )}

      <AddPayableDialog
        isOpen={isDialogOpen}
        onClose={closeCreatePayable}
        onSuccess={loadAnalytics}
      />
    </div>
  );
}