import mongoose from "mongoose";
import Payment from "../../models/paymentModel.js";
import Credit from "../../models/creditModel.js";

const getCreditStatus = (allocated, max) =>
  allocated === 0 ? "Pending" : allocated < max ? "Partially Allocated" : "Fully Allocated";

export const createBulkPayment = async (req, res) => {
  try {
    const userId = req.user?._id;
    if (!userId) {
      return res.status(401).json({ success: false, message: "Your login session is invalid. Please log in again." });
    }

    let itemsToProcess = req.body;
    if (req.body && Array.isArray(req.body.payments)) {
      itemsToProcess = req.body.payments;
    }

    if (!Array.isArray(itemsToProcess) || itemsToProcess.length === 0) {
      return res.status(400).json({ success: false, message: "Please provide an array of payments." });
    }

    const validDocuments = [];
    const invalidItems = [];
    const seenInBatch = new Set();
    const allowedPaymentMethods = ["CASH", "BANK", "CHEQUE", "ONLINE", "UPI"];

    // 1. Batch Validation & Normalization
    itemsToProcess.forEach((item, index) => {
      const errors = [];
      const invoiceNumber = String(item?.invoiceNumber || "").trim();
      const grnNumber = String(item?.grnNumber || "").trim();
      const supplierName = String(item?.supplierName || "").trim();
      const paymentMethod = String(item?.paymentMethod || "").toUpperCase().trim();
      const amount = Number(item?.paidAmount);
      const paymentDate = new Date(item?.paymentDate);
      const transactionNumber = String(item?.transactionNumber || "").trim();
      const creditNoteNumber = item?.creditNoteNumber ? String(item.creditNoteNumber).trim() : null;

      if (!invoiceNumber) errors.push("Please provide the invoice number.");
      if (!grnNumber) errors.push("Please provide the GRN number.");
      if (!supplierName) errors.push("Please provide the supplier name.");
      if (isNaN(amount) || amount <= 0) errors.push("Please provide a payment amount greater than 0.");
      if (!item?.paymentDate || isNaN(paymentDate.getTime())) errors.push("Please provide a valid payment date.");

      if (!allowedPaymentMethods.includes(paymentMethod)) {
        errors.push("Please select Cash, Bank, Cheque, Online, or UPI as the payment method.");
      }

      // Credit note is required for ALL payment methods
      if (!creditNoteNumber) {
        errors.push("Please provide the Credit Note Number.");
      }

      // Transaction number is required only for non-CASH payments
      if (paymentMethod !== "CASH" && !transactionNumber) {
        errors.push(`Please provide the transaction number for ${paymentMethod} payments.`);
      }

      if (invoiceNumber && grnNumber) {
        const key = `${invoiceNumber}_${grnNumber}`;
        if (seenInBatch.has(key)) {
          errors.push(`Invoice '${invoiceNumber}' and GRN '${grnNumber}' appears more than once in this request.`);
        } else {
          seenInBatch.add(key);
        }
      }

      if (errors.length > 0) {
        invalidItems.push({ index: index + 1, invoiceNumber: invoiceNumber || "Not provided", grnNumber: grnNumber || "Not provided", errors });
        return;
      }

      validDocuments.push({
        invoiceNumber,
        grnNumber,
        supplierName,
        paidAmount: amount,
        paymentDate,
        paymentMethod,
        creditNoteNumber,
        transactionNumber: paymentMethod === "CASH" ? null : transactionNumber,
        paymentBy: userId,
        status: "Pending",
        updateLogs: [],
      });
    });

    // 2. Database Duplicate Check
    if (validDocuments.length > 0) {
      const pairsToCheck = validDocuments.map((item) => ({ invoiceNumber: item.invoiceNumber, grnNumber: item.grnNumber }));
      const existingRecords = await Payment.find({ $or: pairsToCheck }).select("invoiceNumber grnNumber").lean();
      const existingSet = new Set(existingRecords.map((doc) => `${doc.invoiceNumber}_${doc.grnNumber}`));

      for (let i = validDocuments.length - 1; i >= 0; i--) {
        const item = validDocuments[i];
        const key = `${item.invoiceNumber}_${item.grnNumber}`;

        if (existingSet.has(key)) {
          invalidItems.push({
            index: i + 1,
            invoiceNumber: item.invoiceNumber,
            grnNumber: item.grnNumber,
            errors: [`A payment already exists for Invoice '${item.invoiceNumber}' and GRN '${item.grnNumber}'.`],
          });
          validDocuments.splice(i, 1);
        }
      }
    }

    if (validDocuments.length === 0) {
      return res.status(400).json({
        success: false,
        message: "None of the payments could be submitted. Please correct the errors and try again.",
        summary: { totalReceived: itemsToProcess.length, successfullyInserted: 0, failedCount: invalidItems.length },
        invalidItems,
      });
    }

    // 3. Transactional Execution & Credit Sync
    const session = await mongoose.startSession();
    let insertedDocs = [];

    try {
      await session.withTransaction(async () => {
        insertedDocs = await Payment.insertMany(validDocuments, { session, ordered: true });

        for (const payment of insertedDocs) {
          const amount = payment.paidAmount;
          const credit = await Credit.findOne({ creditNoteNumber: payment.creditNoteNumber }).session(session);

          if (!credit) throw new Error(`CREDIT_NOT_FOUND:${payment.creditNoteNumber}`);

          const availableAmount = credit.pendingAllocationAmount - credit.totalAllocationRequestAmount;
          if (amount > availableAmount) throw new Error(`CREDIT_INSUFFICIENT_BALANCE:${payment.creditNoteNumber}`);

          credit.totalAllocationRequestAmount += amount;
          credit.allocationRequest.push({ paymentId: payment._id, requestAmount: amount, requestedAt: new Date() });
          credit.status = getCreditStatus(credit.totalAllocatedAmount, credit.creditNoteAmount);

          await credit.save({ session });
        }
      });
    } finally {
      await session.endSession();
    }

    return res.status(invalidItems.length > 0 ? 207 : 201).json({
      success: true,
      message:
        invalidItems.length > 0
          ? "Some payments were submitted successfully. Please review the payments that could not be submitted."
          : "All payments were submitted successfully and are waiting for approval.",
      summary: { totalReceived: itemsToProcess.length, successfullyInserted: insertedDocs.length, failedCount: invalidItems.length },
      data: insertedDocs,
      invalidItems,
    });
  } catch (error) {
    console.error("Error in createBulkPayment:", error);

    if (error.message?.startsWith("CREDIT_NOT_FOUND:")) {
      return res.status(404).json({ success: false, message: `Credit Note '${error.message.split(":")[1]}' could not be found.` });
    }

    if (error.message?.startsWith("CREDIT_INSUFFICIENT_BALANCE:")) {
      return res.status(400).json({ success: false, message: `Credit Note '${error.message.split(":")[1]}' does not have enough available balance.` });
    }

    if (error.code === 11000) {
      return res.status(409).json({ success: false, message: "One or more payments already exist for the Invoice and GRN combination." });
    }

    return res.status(500).json({ success: false, message: "Something went wrong while creating the payments." });
  }
};