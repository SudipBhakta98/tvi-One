import mongoose from "mongoose";
import Payment from "../../models/paymentModel.js";
import Credit from "../../models/creditModel.js";

import {
  restoreAdjustedAdvances,
  advanceErrorResponse,
} from "../../utils/advanceSettlement.js";

export const deletePayment = async (req, res) => {
  const { paymentId } = req.params;

  // ---------------------------------------------------------
  // Permission
  // ---------------------------------------------------------
  if (req.user?.role !== "Super User") {
    return res.status(403).json({
      success: false,
      message:
        "You do not have permission to delete this payment.",
    });
  }

  // ---------------------------------------------------------
  // Validate Payment ID
  // ---------------------------------------------------------
  if (!mongoose.Types.ObjectId.isValid(paymentId)) {
    return res.status(400).json({
      success: false,
      message: "The payment ID is not valid.",
    });
  }

  // ---------------------------------------------------------
  // Find Payment
  // ---------------------------------------------------------
  const payment = await Payment.findById(paymentId).lean();

  if (!payment) {
    return res.status(404).json({
      success: false,
      message:
        "We couldn't find this payment.",
    });
  }

  // ---------------------------------------------------------
  // Advance payment itself cannot be deleted here
  // ---------------------------------------------------------
  if (payment.paymentType === "ADVANCE") {
    return res.status(400).json({
      success: false,
      message:
        "Advance payments cannot be deleted here. Cancel the advance from the Advance Register.",
    });
  }

  // ---------------------------------------------------------
  // Approved payment cannot be deleted
  // ---------------------------------------------------------
  if (payment.status === "Approved") {
    return res.status(400).json({
      success: false,
      message:
        "Approved payments cannot be deleted.",
    });
  }

  const session =
    await mongoose.startSession();

  try {
    await session.withTransaction(async () => {

      // =====================================================
      // 1. RESTORE SUPPLIER ADVANCE
      //
      // The advance was already settled when this payment
      // was created/edited.
      //
      // Therefore we MUST restore it before deleting the
      // payment.
      // =====================================================
      if (
        payment.advanceAllocations &&
        payment.advanceAllocations.length > 0
      ) {
        await restoreAdjustedAdvances({
          payment,
          userId: req.user._id,
          session,
          reason:
            `payment ${paymentId} was deleted.`,
        });
      }

      // =====================================================
      // 2. REMOVE CREDIT NOTE ALLOCATION REQUEST
      //
      // Payment is Pending, so its Credit Note portion is
      // still only an allocation request.
      // =====================================================
      if (
        payment.creditNoteNumber &&
        payment.status === "Pending"
      ) {
        const credit =
          await Credit.findOne({
            creditNoteNumber:
              payment.creditNoteNumber,
          }).session(session);

        if (!credit) {
          throw new Error(
            "CREDIT_NOT_FOUND"
          );
        }

        const requestIndex =
          credit.allocationRequest.findIndex(
            (r) =>
              String(r.paymentId) ===
              String(payment._id)
          );

        if (requestIndex === -1) {
          throw new Error(
            "ALLOCATION_REQUEST_NOT_FOUND"
          );
        }

        const request =
          credit.allocationRequest[
            requestIndex
          ];

        const requestAmount =
          Number(
            request.requestAmount || 0
          );

        // ---------------------------------------------------
        // Remove allocation request amount
        // ---------------------------------------------------
        credit.totalAllocationRequestAmount =
          Math.max(
            0,
            Number(
              credit.totalAllocationRequestAmount ||
                0
            ) - requestAmount
          );

        // ---------------------------------------------------
        // Remove request itself
        // ---------------------------------------------------
        credit.allocationRequest.splice(
          requestIndex,
          1
        );

        // ---------------------------------------------------
        // Recalculate Credit Note status
        // ---------------------------------------------------
        if (
          Number(
            credit.totalAllocatedAmount || 0
          ) >=
          Number(
            credit.creditNoteAmount || 0
          )
        ) {
          credit.status =
            "Fully Allocated";
        } else if (
          Number(
            credit.totalAllocatedAmount || 0
          ) > 0
        ) {
          credit.status =
            "Partially Allocated";
        } else {
          credit.status =
            "Pending";
        }

        // ---------------------------------------------------
        // Audit log
        // ---------------------------------------------------
        credit.updateLogs.push({
          updatedBy:
            req.user._id,
          updatedAt:
            new Date(),
          remark:
            `Allocation request removed because payment ${paymentId} was deleted.`,
        });

        await credit.save({
          session,
        });
      }

      // =====================================================
      // 3. DELETE PAYMENT
      // =====================================================
      const deleteResult =
        await Payment.deleteOne(
          {
            _id: paymentId,
          },
          {
            session,
          }
        );

      if (
        deleteResult.deletedCount !== 1
      ) {
        throw new Error(
          "PAYMENT_DELETE_FAILED"
        );
      }
    });

    // ---------------------------------------------------------
    // Success
    // ---------------------------------------------------------
    return res.status(200).json({
      success: true,
      message:
        "Payment has been deleted successfully.",
    });

  } catch (error) {
    console.error(
      "Error deleting payment:",
      error
    );

    // ---------------------------------------------------------
    // Advance errors
    // ---------------------------------------------------------
    const adv =
      advanceErrorResponse(error);

    if (adv) {
      return res.status(adv[0]).json({
        success: false,
        message: adv[1],
      });
    }

    // ---------------------------------------------------------
    // Credit Note not found
    // ---------------------------------------------------------
    if (
      error.message ===
      "CREDIT_NOT_FOUND"
    ) {
      return res.status(404).json({
        success: false,
        message:
          "Associated Credit Note could not be found.",
      });
    }

    // ---------------------------------------------------------
    // Allocation request missing
    // ---------------------------------------------------------
    if (
      error.message ===
      "ALLOCATION_REQUEST_NOT_FOUND"
    ) {
      return res.status(409).json({
        success: false,
        message:
          "Payment allocation request could not be found.",
      });
    }

    // ---------------------------------------------------------
    // Payment deletion failed
    // ---------------------------------------------------------
    if (
      error.message ===
      "PAYMENT_DELETE_FAILED"
    ) {
      return res.status(500).json({
        success: false,
        message:
          "The payment could not be deleted.",
      });
    }

    // ---------------------------------------------------------
    // Generic
    // ---------------------------------------------------------
    return res.status(500).json({
      success: false,
      message:
        "Something went wrong while deleting the payment.",
    });

  } finally {
    await session.endSession();
  }
};