import mongoose from "mongoose";
import Payment from "../../models/paymentModel.js";
import Credit from "../../models/creditModel.js";
import SupplierAdvance from "../../models/supplierAdvanceModel.js";

import {
  restoreAdjustedAdvances,
  advanceErrorResponse,
} from "../../utils/advanceSettlement.js";

export const updatePaymentStatus = async (req, res) => {
  const session = await mongoose.startSession();

  try {
    const { paymentId } = req.params;
    const { status } = req.body;

    // ---------------------------------------------------------
    // Permission
    // ---------------------------------------------------------
    if (req.user?.role !== "Super User") {
      return res.status(403).json({
        success: false,
        message:
          "You do not have permission to approve or reject this payment.",
      });
    }

    // ---------------------------------------------------------
    // Validate payment ID
    // ---------------------------------------------------------
    if (!mongoose.Types.ObjectId.isValid(paymentId)) {
      return res.status(400).json({
        success: false,
        message: "The payment ID is not valid.",
      });
    }

    // ---------------------------------------------------------
    // Validate status
    // ---------------------------------------------------------
    if (!["Approved", "Rejected"].includes(status)) {
      return res.status(400).json({
        success: false,
        message:
          "Please choose either Approve or Reject.",
      });
    }

    const isApproved = status === "Approved";

    // =========================================================
    // TRANSACTION
    // =========================================================
    await session.withTransaction(async () => {
      const payment =
        await Payment.findById(paymentId)
          .session(session);

      if (!payment) {
        throw new Error(
          "PAYMENT_NOT_FOUND"
        );
      }

      // -------------------------------------------------------
      // Payment must still be pending
      // -------------------------------------------------------
      if (payment.status !== "Pending") {
        const error =
          new Error(
            "ALREADY_PROCESSED"
          );

        error.status =
          payment.status;

        throw error;
      }

      // =======================================================
      // ADVANCE PAYMENT ITSELF
      //
      // This is different from an invoice payment using an
      // advance.
      //
      // A paymentType === "ADVANCE" creates the SupplierAdvance
      // record and that record itself needs approval.
      // =======================================================
      if (
        payment.paymentType ===
        "ADVANCE"
      ) {
        const advance =
          await SupplierAdvance.findOne({
            paymentId:
              payment._id,
          }).session(session);

        if (
          advance &&
          advance.status === "Pending"
        ) {
          advance.status =
            isApproved
              ? "Approved"
              : "Cancelled";

          advance.updateLogs.push({
            updatedBy:
              req.user._id,
            updatedAt:
              new Date(),
            remark:
              `Advance ${isApproved ? "approved" : "cancelled"} from payment approval.`,
          });

          await advance.save({
            session,
          });
        }
      }

      // =======================================================
      // CREDIT NOTE PORTION
      //
      // Credit Notes still use an approval/request workflow.
      // =======================================================
      if (payment.creditNoteNumber) {
        const credit =
          await Credit.findOne({
            creditNoteNumber:
              payment.creditNoteNumber,
          }).session(session);

        if (!credit) {
          throw new Error(
            "CREDIT_NOT_FOUND"
          );
        }

        const requestIndex =
          credit.allocationRequest.findIndex(
            (r) =>
              String(r.paymentId) ===
              String(paymentId)
          );

        if (requestIndex === -1) {
          throw new Error(
            "ALLOCATION_REQUEST_NOT_FOUND"
          );
        }

        const request =
          credit.allocationRequest[
            requestIndex
          ];

        const reqAmount =
          Number(
            request.requestAmount
          );

        // -----------------------------------------------------
        // Remove pending request
        // -----------------------------------------------------
        credit.totalAllocationRequestAmount =
          Math.max(
            0,
            Number(
              credit.totalAllocationRequestAmount ||
                0
            ) - reqAmount
          );

        // -----------------------------------------------------
        // Approve Credit Note allocation
        // -----------------------------------------------------
        if (isApproved) {
          credit.totalAllocatedAmount =
            Number(
              credit.totalAllocatedAmount ||
                0
            ) + reqAmount;

          credit.pendingAllocationAmount =
            Math.max(
              0,
              Number(
                credit.pendingAllocationAmount ||
                  0
              ) - reqAmount
            );

          credit.allocations.push({
            paymentId:
              payment._id,
            allocatedAmount:
              reqAmount,
            allocatedAt:
              new Date(),
          });
        }

        // -----------------------------------------------------
        // Remove request
        // -----------------------------------------------------
        credit.allocationRequest.splice(
          requestIndex,
          1
        );

        // -----------------------------------------------------
        // Recalculate Credit status
        // -----------------------------------------------------
        if (
          Number(
            credit.totalAllocatedAmount
          ) >=
          Number(
            credit.creditNoteAmount
          )
        ) {
          credit.status =
            "Fully Allocated";
        } else if (
          Number(
            credit.totalAllocatedAmount
          ) > 0
        ) {
          credit.status =
            "Partially Allocated";
        } else {
          credit.status =
            "Pending";
        }

        credit.updateLogs.push({
          updatedBy:
            req.user._id,
          updatedAt:
            new Date(),
          remark: isApproved
            ? `Payment ${paymentId} was approved and Credit Note allocation was completed.`
            : `Payment ${paymentId} was rejected and Credit Note allocation request was removed.`,
        });

        await credit.save({
          session,
        });
      }

      // =======================================================
      // SUPPLIER ADVANCE PORTION
      //
      // IMPORTANT:
      //
      // The advance was already adjusted when the payment was
      // created/edited.
      //
      // Therefore:
      //
      // APPROVE:
      //     Do NOTHING to the advance.
      //
      // REJECT:
      //     Restore the already-adjusted advance.
      // =======================================================
      if (
        payment.advanceAllocations?.length
      ) {
        if (!isApproved) {
          await restoreAdjustedAdvances({
            payment,
            userId:
              req.user._id,
            session,
            reason:
              `payment ${paymentId} was rejected.`,
          });
        }
      }

      // =======================================================
      // Update Payment Status
      // =======================================================
      payment.status =
        status;

      payment.approvedBy =
        req.user._id;

      payment.approvedAt =
        new Date();

      await payment.save({
        session,
      });
    });

    // =========================================================
    // SUCCESS
    // =========================================================
    return res.status(200).json({
      success: true,
      message: isApproved
        ? "Payment has been approved successfully."
        : "Payment has been rejected successfully.",
    });

  } catch (error) {
    console.error(
      "Error updating payment status:",
      error
    );

    // ---------------------------------------------------------
    // Advance errors
    // ---------------------------------------------------------
    const adv =
      advanceErrorResponse(error);

    if (adv) {
      return res.status(adv[0]).json({
        success: false,
        message: adv[1],
      });
    }

    // ---------------------------------------------------------
    // Payment not found
    // ---------------------------------------------------------
    if (
      error.message ===
      "PAYMENT_NOT_FOUND"
    ) {
      return res.status(404).json({
        success: false,
        message:
          "We couldn't find this payment.",
      });
    }

    // ---------------------------------------------------------
    // Already processed
    // ---------------------------------------------------------
    if (
      error.message ===
      "ALREADY_PROCESSED"
    ) {
      return res.status(400).json({
        success: false,
        message:
          `This payment has already been ${String(
            error.status
          ).toLowerCase()}.`,
      });
    }

    // ---------------------------------------------------------
    // Credit Note not found
    // ---------------------------------------------------------
    if (
      error.message ===
      "CREDIT_NOT_FOUND"
    ) {
      return res.status(404).json({
        success: false,
        message:
          "Associated Credit Note could not be found.",
      });
    }

    // ---------------------------------------------------------
    // Credit allocation request not found
    // ---------------------------------------------------------
    if (
      error.message ===
      "ALLOCATION_REQUEST_NOT_FOUND"
    ) {
      return res.status(409).json({
        success: false,
        message:
          "Payment allocation request could not be found.",
      });
    }

    // ---------------------------------------------------------
    // Generic error
    // ---------------------------------------------------------
    return res.status(500).json({
      success: false,
      message:
        "Something went wrong while updating the payment status.",
    });

  } finally {
    await session.endSession();
  }
};