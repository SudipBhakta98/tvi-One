import mongoose from "mongoose";

import Payment from "../../models/paymentModel.js";
import Credit from "../../models/creditModel.js";

import {
  getInvoiceFinancials,
} from "../../utils/invoiceFinancials.js";

import {
  round2,
  normalizeAdvanceInput,
  settleAdvancesImmediately,
  restoreAdjustedAdvances,
  advanceErrorResponse,
} from "../../utils/advanceSettlement.js";

const getCreditStatus = (
  allocated,
  max
) =>
  allocated === 0
    ? "Pending"
    : allocated < max
      ? "Partially Allocated"
      : "Fully Allocated";

export const updatePayment = async (req, res) => {
  const session = await mongoose.startSession();

  try {
    const { paymentId } = req.params;

    const userId = req.user?._id;

    // ---------------------------------------------------------
    // Authentication
    // ---------------------------------------------------------
    if (!userId) {
      return res.status(401).json({
        success: false,
        message:
          "Your login session is invalid. Please log in again.",
      });
    }

    // ---------------------------------------------------------
    // Validate payment ID
    // ---------------------------------------------------------
    if (!mongoose.Types.ObjectId.isValid(paymentId)) {
      return res.status(400).json({
        success: false,
        message: "The payment ID is not valid.",
      });
    }

    const {
      supplierName,
      paidAmount,
      paymentDate,
      paymentMethod,
      transactionNumber,
      creditNoteNumber,
      advanceAllocations,
      remark,
    } = req.body;

    // ---------------------------------------------------------
    // Validate remark
    // ---------------------------------------------------------
    const trimmedRemark = String(
      remark || ""
    ).trim();

    if (!trimmedRemark) {
      return res.status(400).json({
        success: false,
        message:
          "Please provide a reason for updating the payment.",
      });
    }

    // ---------------------------------------------------------
    // Find payment
    // ---------------------------------------------------------
    const payment = await Payment.findById(paymentId);

    if (!payment) {
      return res.status(404).json({
        success: false,
        message: "Payment record not found.",
      });
    }

    // ---------------------------------------------------------
    // Advance payment itself cannot be edited here
    // ---------------------------------------------------------
    if (payment.paymentType === "ADVANCE") {
      return res.status(400).json({
        success: false,
        message:
          "Advance payments cannot be edited here. Use the Advance Register.",
      });
    }

    // ---------------------------------------------------------
    // Approved payment cannot be edited
    // ---------------------------------------------------------
    if (payment.status === "Approved") {
      return res.status(400).json({
        success: false,
        message:
          "Approved payments cannot be edited.",
      });
    }

    // ---------------------------------------------------------
    // Allowed payment methods
    // ---------------------------------------------------------
    const allowedMethods = [
      "CASH",
      "BANK",
      "CHEQUE",
      "ONLINE",
      "UPI",
    ];

    const newPaymentMethod =
      paymentMethod !== undefined
        ? String(paymentMethod)
            .toUpperCase()
            .trim()
        : payment.paymentMethod;

    if (!allowedMethods.includes(newPaymentMethod)) {
      return res.status(400).json({
        success: false,
        message:
          "Please select Cash, Bank, Cheque, Online, or UPI as the payment method.",
      });
    }

    // ---------------------------------------------------------
    // Payment amount
    // ---------------------------------------------------------
    const newPaidAmount =
      paidAmount !== undefined
        ? round2(Number(paidAmount))
        : round2(Number(payment.paidAmount));

    if (
      !Number.isFinite(newPaidAmount) ||
      newPaidAmount <= 0
    ) {
      return res.status(400).json({
        success: false,
        message:
          "Please provide a payment amount greater than 0.",
      });
    }

    // ---------------------------------------------------------
    // Payment date
    // ---------------------------------------------------------
    let newPaymentDate = payment.paymentDate;

    if (paymentDate !== undefined) {
      const parsedDate = new Date(paymentDate);

      if (Number.isNaN(parsedDate.getTime())) {
        return res.status(400).json({
          success: false,
          message:
            "Please provide a valid payment date.",
        });
      }

      newPaymentDate = parsedDate;
    }

    // ---------------------------------------------------------
    // Supplier
    // ---------------------------------------------------------
    const newSupplierName =
      supplierName !== undefined
        ? String(supplierName).trim()
        : String(payment.supplierName || "").trim();

    if (!newSupplierName) {
      return res.status(400).json({
        success: false,
        message:
          "Please provide the supplier name.",
      });
    }

    // ---------------------------------------------------------
    // Credit Note
    // ---------------------------------------------------------
    let newCreditNoteNumber =
      payment.creditNoteNumber
        ? String(payment.creditNoteNumber).trim()
        : null;

    if (creditNoteNumber !== undefined) {
      const value = String(
        creditNoteNumber || ""
      ).trim();

      newCreditNoteNumber = value || null;
    }

    // ---------------------------------------------------------
    // Transaction number
    // ---------------------------------------------------------
    let newTransactionNumber =
      payment.transactionNumber
        ? String(payment.transactionNumber).trim()
        : null;

    if (transactionNumber !== undefined) {
      const value = String(
        transactionNumber || ""
      ).trim();

      newTransactionNumber = value || null;
    }

    // ---------------------------------------------------------
    // Advance handling
    //
    // undefined -> keep existing advance selection
    // []        -> remove advance
    // [...]     -> replace with selected advances
    // ---------------------------------------------------------
    let newAdvanceItems;

    try {
      if (advanceAllocations === undefined) {
        newAdvanceItems =
          normalizeAdvanceInput(
            (payment.advanceAllocations || []).map(
              (a) => ({
                advanceId: a.advanceId,
                amount: a.amount,
              })
            )
          );
      } else {
        newAdvanceItems =
          normalizeAdvanceInput(
            advanceAllocations
          );
      }
    } catch (error) {
      return res.status(400).json({
        success: false,
        message:
          "The advance details are not valid.",
      });
    }

    // ---------------------------------------------------------
    // New advance total
    // ---------------------------------------------------------
    const newAdvanceTotal = round2(
      newAdvanceItems.reduce(
        (sum, item) =>
          sum + Number(item.amount || 0),
        0
      )
    );

    // ---------------------------------------------------------
    // Remaining amount that must be covered by Credit Note
    // ---------------------------------------------------------
    const newCreditAmount = round2(
      newPaidAmount - newAdvanceTotal
    );

    // ---------------------------------------------------------
    // Advance cannot exceed payment
    // ---------------------------------------------------------
    if (
      newAdvanceTotal >
      newPaidAmount + 0.001
    ) {
      return res.status(400).json({
        success: false,
        message:
          "The advance used cannot be more than the payment amount.",
      });
    }

    // ---------------------------------------------------------
    // Credit Note required for remaining amount
    // ---------------------------------------------------------
    if (
      newCreditAmount > 0 &&
      !newCreditNoteNumber
    ) {
      return res.status(400).json({
        success: false,
        message:
          newAdvanceTotal > 0
            ? `₹${newCreditAmount} is not covered by the advance. Please select a Credit Note for the remaining amount.`
            : "Please provide the Credit Note Number.",
      });
    }

    // ---------------------------------------------------------
    // Transaction number required when actual money remains
    // ---------------------------------------------------------
    if (
      newCreditAmount > 0 &&
      newPaymentMethod !== "CASH" &&
      !newTransactionNumber
    ) {
      return res.status(400).json({
        success: false,
        message:
          `Please provide the transaction number for ${newPaymentMethod} payments.`,
      });
    }

    // ---------------------------------------------------------
    // Old Credit Note
    // ---------------------------------------------------------
    const oldCreditNoteNumber =
      payment.creditNoteNumber
        ? String(payment.creditNoteNumber).trim()
        : null;

    // =========================================================
    // TRANSACTION
    // =========================================================
    await session.withTransaction(async () => {

      // -------------------------------------------------------
      // 1. Get invoice financials
      // -------------------------------------------------------
      const financials =
        await getInvoiceFinancials({
          invoiceNumber:
            payment.invoiceNumber,
          grnNumber:
            payment.grnNumber,
          session,
          excludePaymentId:
            paymentId,
        });

      // -------------------------------------------------------
      // 2. Payment amount limit
      // -------------------------------------------------------
      if (
        newPaidAmount >
        financials.maxAllowedAmount + 0.001
      ) {
        const error =
          new Error(
            "PAYMENT_LIMIT_EXCEEDED"
          );

        error.details = financials;

        throw error;
      }

      // =======================================================
      // 3. RESTORE OLD ADVANCE
      //
      // IMPORTANT:
      // The old advance was already settled immediately.
      //
      // Therefore we MUST restore it before applying the
      // newly selected advance.
      // =======================================================
      if (
        payment.advanceAllocations &&
        payment.advanceAllocations.length > 0
      ) {
        await restoreAdjustedAdvances({
          payment,
          userId,
          session,
          reason:
            `payment ${paymentId} was updated.`,
        });
      }

      // =======================================================
      // 4. REMOVE OLD CREDIT NOTE REQUEST
      // =======================================================
      if (oldCreditNoteNumber) {
        const oldCredit =
          await Credit.findOne({
            creditNoteNumber:
              oldCreditNoteNumber,
          }).session(session);

        if (!oldCredit) {
          throw new Error(
            "OLD_CREDIT_NOT_FOUND"
          );
        }

        const index =
          oldCredit.allocationRequest.findIndex(
            (item) =>
              String(item.paymentId) ===
              String(paymentId)
          );

        /*
         * It is possible that the payment has no
         * allocation request, for example if the
         * payment data was created under an older
         * workflow.
         */
        if (index !== -1) {
          const [
            oldRequest,
          ] =
            oldCredit.allocationRequest.splice(
              index,
              1
            );

          oldCredit.totalAllocationRequestAmount =
            Math.max(
              0,
              round2(
                Number(
                  oldCredit.totalAllocationRequestAmount ||
                    0
                ) -
                  Number(
                    oldRequest.requestAmount ||
                      0
                  )
              )
            );

          oldCredit.status =
            getCreditStatus(
              Number(
                oldCredit.totalAllocatedAmount ||
                  0
              ),
              Number(
                oldCredit.creditNoteAmount ||
                  0
              )
            );

          oldCredit.updateLogs.push({
            updatedBy: userId,
            updatedAt: new Date(),
            remark:
              `Allocation request removed because payment ${paymentId} was updated.`,
          });

          await oldCredit.save({
            session,
          });
        }
      }

      // =======================================================
      // 5. APPLY NEW ADVANCE IMMEDIATELY
      // =======================================================
      let newAdvanceAllocations = [];

      if (newAdvanceItems.length > 0) {
        newAdvanceAllocations =
          await settleAdvancesImmediately({
            items: newAdvanceItems,
            payment,
            supplierName:
              newSupplierName,
            userId,
            session,
          });
      }

      // =======================================================
      // 6. CREATE NEW CREDIT NOTE REQUEST
      // =======================================================
      if (newCreditAmount > 0) {
        const newCredit =
          await Credit.findOne({
            creditNoteNumber:
              newCreditNoteNumber,
          }).session(session);

        if (!newCredit) {
          throw new Error(
            "NEW_CREDIT_NOT_FOUND"
          );
        }

        const availableAmount =
          round2(
            Number(
              newCredit.pendingAllocationAmount ||
                0
            ) -
              Number(
                newCredit.totalAllocationRequestAmount ||
                  0
              )
          );

        if (
          newCreditAmount >
          availableAmount + 0.001
        ) {
          const error =
            new Error(
              "CREDIT_INSUFFICIENT_BALANCE"
            );

          error.available =
            availableAmount;

          throw error;
        }

        newCredit.totalAllocationRequestAmount =
          round2(
            Number(
              newCredit.totalAllocationRequestAmount ||
                0
            ) +
              newCreditAmount
          );

        newCredit.allocationRequest.push({
          paymentId: payment._id,
          requestAmount:
            newCreditAmount,
          requestedAt: new Date(),
        });

        newCredit.status =
          getCreditStatus(
            Number(
              newCredit.totalAllocatedAmount ||
                0
            ),
            Number(
              newCredit.creditNoteAmount ||
                0
            )
          );

        newCredit.updateLogs.push({
          updatedBy: userId,
          updatedAt: new Date(),
          remark:
            `Allocation request created because payment ${paymentId} was updated.`,
        });

        await newCredit.save({
          session,
        });
      }

      // =======================================================
      // 7. UPDATE PAYMENT
      // =======================================================
      payment.supplierName =
        newSupplierName;

      payment.paidAmount =
        newPaidAmount;

      payment.paymentDate =
        newPaymentDate;

      payment.paymentMethod =
        newPaymentMethod;

      payment.creditNoteNumber =
        newCreditAmount > 0
          ? newCreditNoteNumber
          : null;

      payment.advanceAllocations =
        newAdvanceAllocations;

      payment.advanceAmount =
        newAdvanceTotal;

      payment.transactionNumber =
        newPaymentMethod === "CASH" ||
        newCreditAmount <= 0
          ? null
          : newTransactionNumber;

      /*
       * The payment itself goes through approval again.
       *
       * Important:
       * The advance is ALREADY settled.
       * Only the payment approval remains pending.
       */
      payment.status = "Pending";

      payment.approvedBy = undefined;
      payment.approvedAt = undefined;

      payment.updateLogs.push({
        updatedBy: userId,
        updatedAt: new Date(),
        remark: trimmedRemark,
      });

      await payment.save({
        session,
      });
    });

    // ---------------------------------------------------------
    // Success
    // ---------------------------------------------------------
    return res.status(200).json({
      success: true,
      message:
        "Payment updated successfully and sent for approval again.",
    });

  } catch (error) {
    console.error(
      "Error updating payment:",
      error
    );

    // ---------------------------------------------------------
    // Advance errors
    // ---------------------------------------------------------
    const adv =
      advanceErrorResponse(error);

    if (adv) {
      return res.status(adv[0]).json({
        success: false,
        message: adv[1],
      });
    }

    // ---------------------------------------------------------
    // Payment limit
    // ---------------------------------------------------------
    if (
      error.message ===
      "PAYMENT_LIMIT_EXCEEDED"
    ) {
      return res.status(400).json({
        success: false,
        message:
          "Payment amount exceeds the maximum allowed payment amount.",
        outstandingAmount:
          error.details?.outstandingAmount,
        totalPendingPayment:
          error.details?.totalPendingPayment,
        maxAllowedAmount:
          error.details?.maxAllowedAmount,
      });
    }

    // ---------------------------------------------------------
    // Old Credit Note not found
    // ---------------------------------------------------------
    if (
      error.message ===
      "OLD_CREDIT_NOT_FOUND"
    ) {
      return res.status(404).json({
        success: false,
        message:
          "The previous Credit Note could not be found.",
      });
    }

    // ---------------------------------------------------------
    // New Credit Note not found
    // ---------------------------------------------------------
    if (
      error.message ===
      "NEW_CREDIT_NOT_FOUND"
    ) {
      return res.status(404).json({
        success: false,
        message:
          "The new Credit Note could not be found.",
      });
    }

    // ---------------------------------------------------------
    // Credit balance
    // ---------------------------------------------------------
    if (
      error.message ===
      "CREDIT_INSUFFICIENT_BALANCE"
    ) {
      return res.status(400).json({
        success: false,
        message:
          "The Credit Note does not have enough available allocation balance for this payment.",
        available:
          error.available,
      });
    }

    // ---------------------------------------------------------
    // Old allocation request
    // ---------------------------------------------------------
    if (
      error.message ===
      "OLD_ALLOCATION_REQUEST_NOT_FOUND"
    ) {
      return res.status(409).json({
        success: false,
        message:
          "The payment's existing allocation request could not be found.",
      });
    }

    // ---------------------------------------------------------
    // Generic
    // ---------------------------------------------------------
    return res.status(500).json({
      success: false,
      message:
        "Something went wrong while updating the payment.",
    });

  } finally {
    await session.endSession();
  }
};