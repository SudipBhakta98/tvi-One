import Payment from "../../models/paymentModel.js";

export const createPayment = async (req, res) => {
  try {
    // 1. GET USER FROM JWT
    const userId = req.user?._id;

    if (!userId) {
      return res.status(401).json({
        success: false,
        message: "Your login session is invalid. Please log in again.",
      });
    }

    // 2. PARSE & NORMALIZE PAYLOAD
    let payload = req.body;

    if (payload && Array.isArray(payload.payments)) {
      payload = payload.payments;
    }

    const isBulk = Array.isArray(payload);
    const itemsToProcess = isBulk ? payload : [payload];

    if (itemsToProcess.length === 0) {
      return res.status(400).json({
        success: false,
        message: "Please provide at least one payment.",
      });
    }

    // 3. TARGETED DATABASE DUPLICATE CHECK
    const pairsToCheck = itemsToProcess
      .filter((item) => item?.invoiceNumber && item?.grnNumber)
      .map((item) => ({
        invoiceNumber: String(item.invoiceNumber).trim(),
        grnNumber: String(item.grnNumber).trim(),
      }));

    let existingSet = new Set();
    if (pairsToCheck.length > 0) {
      const existingRecords = await Payment.find({ $or: pairsToCheck })
        .select("invoiceNumber grnNumber -_id")
        .lean();

      existingSet = new Set(
        existingRecords.map((doc) => `${doc.invoiceNumber}_${doc.grnNumber}`),
      );
    }

    // 4. PREPARE PROCESSING CONTAINERS
    const validDocuments = [];
    const invalidItems = [];
    const seenInBatch = new Set();

    const allowedPaymentMethods = ["CASH", "BANK", "CHEQUE", "ONLINE", "UPI"];

    // 5. VALIDATE EACH PAYMENT
    itemsToProcess.forEach((item, index) => {
      const itemIndex = index + 1;
      const errors = [];

      // Extract & Safe Coercion
      const invoiceNumber = item?.invoiceNumber
        ? String(item.invoiceNumber).trim()
        : "";
      const grnNumber = item?.grnNumber ? String(item.grnNumber).trim() : "";
      const supplierName = item?.supplierName
        ? String(item.supplierName).trim()
        : "";
      const paymentMethod = item?.paymentMethod
        ? String(item.paymentMethod).toUpperCase().trim()
        : "";
      const paidAmount = Number(item?.paidAmount);
      const paymentDate = new Date(item?.paymentDate);
      const transactionNumber = item?.transactionNumber
        ? String(item.transactionNumber).trim()
        : "";
      const creditNoteNumber = item?.creditNoteNumber || null;

      // Basic Validation
      if (!invoiceNumber) errors.push("Please provide the invoice number.");
      if (!grnNumber) errors.push("Please provide the GRN number.");
      if (!supplierName) errors.push("Please provide the supplier name.");
      if (isNaN(paidAmount) || paidAmount <= 0)
        errors.push("Please provide a payment amount greater than 0.");
      if (!item?.paymentDate || isNaN(paymentDate.getTime()))
        errors.push("Please provide a valid payment date.");

      // Payment Method Validation
      if (!paymentMethod || !allowedPaymentMethods.includes(paymentMethod)) {
        errors.push(
          "Please select Cash, Bank, Cheque, Online, or UPI as the payment method.",
        );
      }

      // Cash does not require transaction number or Credit ID
      if (paymentMethod !== "CASH") {
        if (!transactionNumber) {
          errors.push(
            `Please provide the transaction number for ${paymentMethod} payments.`,
          );
        }

        if (!creditNoteNumber) {
          errors.push(
            `Please provide the Credit ID for ${paymentMethod} payments.`,
          );
        }
      }

      // Unique Constraint Checks (DB + Batch)
      if (invoiceNumber && grnNumber) {
        const compositeKey = `${invoiceNumber}_${grnNumber}`;

        if (existingSet.has(compositeKey)) {
          errors.push(
            `A payment already exists for Invoice '${invoiceNumber}' and GRN '${grnNumber}'.`,
          );
        } else if (seenInBatch.has(compositeKey)) {
          errors.push(
            `Invoice '${invoiceNumber}' and GRN '${grnNumber}' appears more than once in this request.`,
          );
        } else {
          seenInBatch.add(compositeKey);
        }
      }

      // Collect Errors or Proceed
      if (errors.length > 0) {
        invalidItems.push({
          index: itemIndex,
          invoiceNumber: invoiceNumber || "Not provided",
          grnNumber: grnNumber || "Not provided",
          errors,
        });
        return;
      }

      const paymentDocument = {
        invoiceNumber,
        supplierName,
        grnNumber,
        paidAmount,
        paymentDate,
        paymentMethod,
        creditNoteNumber,
        transactionNumber,
        paymentBy: userId,
        status: "Pending",
           updateLogs: [],
      };

      validDocuments.push(paymentDocument);
    });

    // 6. SINGLE PAYMENT RESPONSE
    if (!isBulk) {
      if (invalidItems.length > 0) {
        return res.status(400).json({
          success: false,
          message: "Please correct the payment details.",
          errors: invalidItems[0].errors,
        });
      }

      const newPayment = await Payment.create(validDocuments[0]);

      return res.status(201).json({
        success: true,
        message: "Payment submitted successfully and is waiting for approval.",
        data: newPayment,
      });
    }

    // 7. BULK PAYMENT INSERTION
    let insertedDocs = [];

    if (validDocuments.length > 0) {
      insertedDocs = await Payment.insertMany(validDocuments, {
        ordered: false,
        runValidators: true,
      });
    }

    // 8. BULK PAYMENT RESPONSE
    if (insertedDocs.length === 0) {
      return res.status(400).json({
        success: false,
        message:
          "None of the payments could be submitted. Please correct the errors and try again.",
        summary: {
          totalReceived: itemsToProcess.length,
          successfullyInserted: 0,
          failedCount: invalidItems.length,
        },
        invalidItems,
      });
    }

    return res.status(invalidItems.length > 0 ? 207 : 201).json({
      success: true,
      message:
        invalidItems.length > 0
          ? "Some payments were submitted successfully. Please review the payments that could not be submitted."
          : "All payments were submitted successfully and are waiting for approval.",
      summary: {
        totalReceived: itemsToProcess.length,
        successfullyInserted: insertedDocs.length,
        failedCount: invalidItems.length,
      },
      data: insertedDocs,
      invalidItems,
    });
  } catch (error) {
    console.error("Error in createPayment:", error);

    if (error.code === 11000) {
      return res.status(409).json({
        success: false,
        message:
          "A payment already exists for this Invoice and GRN combination.",
      });
    }

    return res.status(500).json({
      success: false,
      message: "Something went wrong while creating the payment.",
    });
  }
};
