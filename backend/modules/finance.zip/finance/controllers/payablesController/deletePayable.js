import mongoose from "mongoose";
import Payable from "../../models/payableModel.js";
import Payment from "../../models/paymentModel.js";
import Debit from "../../models/debitModel.js";
import { restoreAdjustedAdvances } from "../../utils/advanceSettlement.js";

export const deletePayable = async (req, res) => {
  const session = await mongoose.startSession();

  try {
    const { id } = req.params;

    // ---------------------------------------------------------
    // 1. Validate Payable ID
    // ---------------------------------------------------------
    if (!id) {
      return res.status(400).json({
        success: false,
        message: "Please provide payable ID.",
      });
    }

    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid payable ID.",
      });
    }

    // ---------------------------------------------------------
    // 2. Start Transaction
    // ---------------------------------------------------------
    session.startTransaction();

    // ---------------------------------------------------------
    // 3. Find Payable
    // ---------------------------------------------------------
    const payableToDelete = await Payable.findById(id).session(session);

    if (!payableToDelete) {
      await session.abortTransaction();

      return res.status(404).json({
        success: false,
        message: "Payable record not found.",
      });
    }

    // ---------------------------------------------------------
    // 4. Invoice identification
    // ---------------------------------------------------------
    const invoiceNumber = String(
      payableToDelete.invoiceNumber || ""
    ).trim();

    const grnNumber = String(
      payableToDelete.grnNumber || ""
    ).trim();

    const compositeFilter = {
      invoiceNumber,
      grnNumber,
    };

    // ---------------------------------------------------------
    // 5. Find associated payments
    // ---------------------------------------------------------
    const payments = await Payment.find(compositeFilter).session(session);

    let restoredAdvancePayments = 0;
    let restoredAdvanceAmount = 0;

    // ---------------------------------------------------------
    // 6. Restore advance adjustments
    //
    // IMPORTANT:
    // Advance settlement is now immediate.
    //
    // Therefore:
    // Pending payment     -> advance was already adjusted
    // Approved payment    -> advance was already adjusted
    //
    // So we ALWAYS restore the adjustment before deleting
    // the payment.
    // ---------------------------------------------------------
    for (const payment of payments) {
      if (
        !payment.advanceAllocations ||
        payment.advanceAllocations.length === 0
      ) {
        continue;
      }

      await restoreAdjustedAdvances({
        payment,
        userId: req.user?._id,
        session,
        reason: `invoice ${invoiceNumber} was deleted.`,
      });

      restoredAdvancePayments += 1;

      restoredAdvanceAmount += (payment.advanceAllocations || []).reduce(
        (total, allocation) =>
          total + Number(allocation.amount || 0),
        0
      );
    }

    // ---------------------------------------------------------
    // 7. Delete associated Payments
    // ---------------------------------------------------------
    const paymentDeleteResult = await Payment.deleteMany(
      compositeFilter,
      { session }
    );

    // ---------------------------------------------------------
    // 8. Delete associated Debit Notes
    // ---------------------------------------------------------
    const debitDeleteResult = await Debit.deleteMany(
      compositeFilter,
      { session }
    );

    // ---------------------------------------------------------
    // 9. Delete Payable
    // ---------------------------------------------------------
    const deletedPayable = await Payable.findByIdAndDelete(id, {
      session,
    });

    if (!deletedPayable) {
      throw new Error("Payable could not be deleted.");
    }

    // ---------------------------------------------------------
    // 10. Commit Transaction
    // ---------------------------------------------------------
    await session.commitTransaction();

    // ---------------------------------------------------------
    // 11. Response
    // ---------------------------------------------------------
    return res.status(200).json({
      success: true,
      message:
        "Payable and all associated payments and debit notes deleted successfully.",

      summary: {
        deletedPayableId: deletedPayable._id,
        invoiceNumber,
        grnNumber,

        deletedPaymentsCount:
          paymentDeleteResult.deletedCount || 0,

        deletedDebitsCount:
          debitDeleteResult.deletedCount || 0,

        restoredAdvancePayments,
        restoredAdvanceAmount: Number(
          restoredAdvanceAmount.toFixed(2)
        ),
      },
    });
  } catch (error) {
    // ---------------------------------------------------------
    // Rollback transaction
    // ---------------------------------------------------------
    if (session.inTransaction()) {
      await session.abortTransaction();
    }

    console.error("Error deleting payable:", error);

    return res.status(500).json({
      success: false,
      message:
        error.message || "Internal Server Error",
    });
  } finally {
    await session.endSession();
  }
};