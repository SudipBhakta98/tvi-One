import SupplierAdvance from "../models/supplierAdvanceModel.js";

export const round2 = (n) =>
  Math.round((Number(n) || 0) * 100) / 100;

export const escapeRegex = (v) =>
  String(v).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

/**
 * Case-insensitive exact match on supplier name.
 */
export const supplierNameFilter = (name) => ({
  $regex: new RegExp(
    `^${escapeRegex(String(name).trim())}$`,
    "i"
  ),
});

/**
 * Advance status after balance changed.
 */
export const getAdvanceStatus = (adv) => {
  if (
    adv.status === "Pending" ||
    adv.status === "Cancelled"
  ) {
    return adv.status;
  }

  if (round2(adv.pendingAdjustmentAmount) <= 0) {
    return "Fully Adjusted";
  }

  if (round2(adv.totalAdjustedAmount) > 0) {
    return "Partially Adjusted";
  }

  return "Approved";
};

/**
 * Available advance balance.
 *
 * Since advance settlement is now immediate,
 * allocationRequest is no longer involved in normal
 * advance settlement.
 */
export const availableOf = (adv) =>
  Math.max(
    0,
    round2(adv.pendingAdjustmentAmount)
  );

/**
 * Validate + normalise advance input.
 *
 * Input:
 * [
 *   {
 *     advanceId,
 *     amount
 *   }
 * ]
 *
 * Output:
 * [
 *   {
 *     advanceId,
 *     amount
 *   }
 * ]
 */
export const normalizeAdvanceInput = (raw) => {
  if (raw === undefined || raw === null) {
    return [];
  }

  if (!Array.isArray(raw)) {
    throw new Error("ADVANCE_INPUT_INVALID");
  }

  const merged = new Map();

  for (const row of raw) {
    const id = String(
      row?.advanceId || ""
    ).trim();

    const amount = round2(row?.amount);

    if (
      !id ||
      !Number.isFinite(amount)
    ) {
      throw new Error(
        "ADVANCE_INPUT_INVALID"
      );
    }

    if (amount <= 0) {
      continue;
    }

    merged.set(
      id,
      round2(
        (merged.get(id) || 0) + amount
      )
    );
  }

  return [...merged.entries()].map(
    ([advanceId, amount]) => ({
      advanceId,
      amount,
    })
  );
};

/**
 * DIRECTLY SETTLE ADVANCES
 *
 * The user explicitly selected the advance,
 * so the advance is consumed immediately.
 *
 * NO allocationRequest is created.
 * NO second approval is required for the advance.
 *
 * Example:
 *
 * Advance balance = ₹1,000
 * Payment uses    = ₹500
 *
 * pendingAdjustmentAmount:
 * 1000 -> 500
 *
 * totalAdjustedAmount:
 * 0 -> 500
 *
 * adjustments:
 * new adjustment record
 */
export const settleAdvancesImmediately = async ({
  items,
  payment,
  supplierName,
  userId,
  session,
}) => {
  const stored = [];

  for (const {
    advanceId,
    amount,
  } of items) {
    const adv =
      await SupplierAdvance.findById(
        advanceId
      ).session(session);

    if (!adv) {
      throw new Error(
        "ADVANCE_NOT_FOUND"
      );
    }

    /**
     * Supplier validation
     */
    if (
      String(adv.supplierName)
        .trim()
        .toLowerCase() !==
      String(supplierName)
        .trim()
        .toLowerCase()
    ) {
      throw new Error(
        "ADVANCE_SUPPLIER_MISMATCH"
      );
    }

    /**
     * Advance must already be approved.
     *
     * The advance itself has already gone through
     * its own approval process when it was created.
     */
    if (
      ![
        "Approved",
        "Partially Adjusted",
      ].includes(adv.status)
    ) {
      const error = new Error(
        "ADVANCE_NOT_USABLE"
      );

      error.advanceNumber =
        adv.advanceNumber;

      throw error;
    }

    /**
     * Check current available balance.
     */
    const available =
      availableOf(adv);

    if (
      amount >
      available + 0.001
    ) {
      const error = new Error(
        "ADVANCE_INSUFFICIENT_BALANCE"
      );

      error.advanceNumber =
        adv.advanceNumber;

      error.available = available;

      throw error;
    }

    /**
     * Immediately consume the advance.
     */
    adv.pendingAdjustmentAmount =
      round2(
        adv.pendingAdjustmentAmount -
          amount
      );

    adv.totalAdjustedAmount =
      round2(
        (adv.totalAdjustedAmount || 0) +
          amount
      );

    /**
     * Record actual adjustment.
     */
    adv.adjustments.push({
      paymentId: payment._id,
      invoiceNumber:
        payment.invoiceNumber,
      adjustedAmount: amount,
      adjustedAt: new Date(),
      adjustedBy: userId,
      remark:
        `Adjusted against invoice ${payment.invoiceNumber}`,
    });

    /**
     * Update status immediately.
     */
    adv.status =
      getAdvanceStatus(adv);

    /**
     * Audit log.
     */
    adv.updateLogs.push({
      updatedBy: userId,
      updatedAt: new Date(),
      remark:
        `₹${amount} directly adjusted against invoice ${payment.invoiceNumber}.`,
    });

    await adv.save({
      session,
    });

    stored.push({
      advanceId: adv._id,
      advanceNumber:
        adv.advanceNumber,
      amount,
    });
  }

  return stored;
};

/**
 * RESTORE ADVANCE
 *
 * Used when a payment that already consumed
 * an advance is deleted/rejected/reversed.
 */
export const restoreAdjustedAdvances = async ({
  payment,
  userId,
  session,
  reason,
}) => {
  for (const alloc of
    payment.advanceAllocations || []) {
    const adv =
      await SupplierAdvance.findById(
        alloc.advanceId
      ).session(session);

    if (!adv) {
      continue;
    }

    const idx =
      adv.adjustments.findIndex(
        (a) =>
          String(a.paymentId) ===
          String(payment._id)
      );

    if (idx === -1) {
      continue;
    }

    const [adjustment] =
      adv.adjustments.splice(
        idx,
        1
      );

    /**
     * Return money to advance.
     */
    adv.pendingAdjustmentAmount =
      round2(
        adv.pendingAdjustmentAmount +
          adjustment.adjustedAmount
      );

    adv.totalAdjustedAmount =
      Math.max(
        0,
        round2(
          adv.totalAdjustedAmount -
            adjustment.adjustedAmount
        )
      );

    adv.status =
      getAdvanceStatus(adv);

    adv.updateLogs.push({
      updatedBy: userId,
      updatedAt: new Date(),
      remark:
        `₹${adjustment.adjustedAmount} restored from invoice ${payment.invoiceNumber}: ${reason}`,
    });

    await adv.save({
      session,
    });
  }
};

/**
 * Find usable advances.
 */
export const findUsableAdvances = async ({
  supplierName,
}) => {
  const advances =
    await SupplierAdvance.find({
      supplierName:
        supplierNameFilter(
          supplierName
        ),

      status: {
        $in: [
          "Approved",
          "Partially Adjusted",
        ],
      },
    })
      .sort({
        createdAt: 1,
      })
      .lean();

  return advances
    .map((a) => {
      const available =
        Math.max(
          0,
          round2(
            a.pendingAdjustmentAmount
          )
        );

      return {
        advanceId: a._id,
        advanceNumber:
          a.advanceNumber,
        advanceAmount:
          a.advanceAmount,
        availableAmount:
          available,
        status: a.status,
        createdAt: a.createdAt,
      };
    })
    .filter(
      (a) =>
        a.availableAmount > 0
    );
};

/**
 * Shared advance error response.
 */
export const advanceErrorResponse = (
  error
) => {
  switch (error.message) {
    case "ADVANCE_INPUT_INVALID":
      return [
        400,
        "The advance details are not valid.",
      ];

    case "ADVANCE_NOT_FOUND":
      return [
        404,
        "The selected advance payment could not be found.",
      ];

    case "ADVANCE_SUPPLIER_MISMATCH":
      return [
        400,
        "The selected advance belongs to a different supplier.",
      ];

    case "ADVANCE_NOT_USABLE":
      return [
        400,
        `Advance ${
          error.advanceNumber || ""
        } is not approved yet, so it cannot be used.`.replace(
          "  ",
          " "
        ),
      ];

    case "ADVANCE_INSUFFICIENT_BALANCE":
      return [
        400,
        `Advance ${
          error.advanceNumber || ""
        } does not have enough available balance${
          error.available !==
          undefined
            ? ` (available ₹${error.available})`
            : ""
        }.`.replace(
          "  ",
          " "
        ),
      ];

    case "ADVANCE_REQUEST_NOT_FOUND":
      return [
        409,
        "The payment's advance reservation could not be found.",
      ];

    case "ADVANCE_EXCEEDS_PAYMENT":
      return [
        400,
        "The advance used cannot be more than the payment amount.",
      ];

    default:
      return null;
  }
};